package de.CaptureTheWool.main;

import de.CaptureTheWool.listener.*;
import de.CaptureTheWool.utils.*;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.ServicesManager;
import org.bukkit.plugin.java.JavaPlugin;

import de.CaptureTheWool.api.LocationAPI;
import de.CaptureTheWool.commands.Stats;
import me.lucko.luckperms.api.LuckPermsApi;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Random;

public class CaptureTheWool extends JavaPlugin {

	ServicesManager manager = Bukkit.getServicesManager();
	
	@Override
	public void onEnable() {
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§7----------------------------------------");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§a──────────────────────────────────");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§a──██████──██████████──██──────██──");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§a──██──────────██──────██──────██──");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§a──██──────────██──────██──────██──");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§a──██──────────██──────██──────██──");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§a──██──────────██──────██──██──██──");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§a──██──────────██──────██████████──");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§a──██──────────██──────████──████──");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§a──██████──────██──────██──────██──");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§a──────────────────────────────────");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§aDas Plugin ist für ZnapLax.de");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§aDas Plugin ist von Woobble & TrainmasterHD");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"");
		registerListener();
		registerCommands();
		setup();
		setupLuckPermsAPI();
		setupWorlds();
		Team.Scoreboard.register();
		MapSystem.selectMap(MapSystem.getMapList().get(new Random().nextInt(MapSystem.getMapList().size())));
		new BukkitRunnable() {
			@Override
			public void run() {
				Data.CLOUDSYSTEM.setState("Online");
			}
		}.runTaskLater(Data.main, 20);
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§aPlugin wurde aktiviert!");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§7-----------------------------------------");
	}

	@Override
	public void onDisable() {
		Data.mysql.close();
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§aPlugin wurde deaktiviert!");
	}

	private void registerListener() {
		PluginManager pm = Bukkit.getPluginManager();

		pm.registerEvents(new BlockPlaceListener(), this);
		pm.registerEvents(new BlockBreakListener(), this);
		pm.registerEvents(new CreatureSpawnListener(), this);
		pm.registerEvents(new EntityDamageListener(), this);
		pm.registerEvents(new FoodLevelChangeListener(), this);
		pm.registerEvents(new GameListener(), this);
		pm.registerEvents(new PlayerDropItemListener(), this);
		pm.registerEvents(new InventoryClickListener(), this);
		pm.registerEvents(new PlayerChatListener(), this);
		pm.registerEvents(new PlayerDeathListener(), this);
		pm.registerEvents(new PlayerInteractListener(), this);
		pm.registerEvents(new PlayerJoinListener(), this);
		pm.registerEvents(new PlayerQuitListener(), this);
		pm.registerEvents(new ServerListPingListener(), this);
		pm.registerEvents(new TeamListener(), this);
		pm.registerEvents(new WeatherChangeListener(), this);
		pm.registerEvents(new de.CaptureTheWool.manager.HologramManager(), this);
		
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§aDie Listener wurden registriert!");
	}
	private void registerCommands() {

		getCommand("stats").setExecutor(new Stats());
		
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§aDie Commands wurden registriert!");
	}
	private void setup() {
		Data.main = this;
		Data.mysql = new MySQL("localhost", 3306, "CaptureTheWool", "root", "+BEzaV.p}zU}e8?Rxx3z");
		Data.mysql.connect();
		MapSystem.setup();
		LocationAPI.setup();
		Bukkit.getMessenger().registerOutgoingPluginChannel(Data.main, "BungeeCord");
		GameState.setState(GameState.LOBBY);
		Countdown.startLobbyCountDown();
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§aDer Setup ist beendet!");
	}

	private void setupWorlds() {
		for (World w : Bukkit.getWorlds()) {
			w.setThundering(false);
			w.setStorm(false);
			w.setTime(0);
			w.setWeatherDuration(0);
			for (Entity ent : w.getEntities()) {
				if (!(ent instanceof Player)) {
					ent.remove();
				}
			}
		}
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§aDie Welten wurden aufgesetzt!");
	}

	private void setupLuckPermsAPI() {
		if (manager.isProvidedFor(LuckPermsApi.class)) {
			Data.api = manager.getRegistration(LuckPermsApi.class).getProvider();
			Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX+"§aDie LuckPermsAPI wurde aufgesetzt!");
		}
	}
}
