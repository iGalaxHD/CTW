package de.CaptureTheWool.commands;


import java.util.UUID;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import de.CaptureTheWool.manager.StatsManager;
import de.CaptureTheWool.manager.UUIDFetcher;
import de.CaptureTheWool.utils.MySQL;

public class Stats
  implements CommandExecutor
{
  public boolean onCommand(CommandSender s, Command cmd, String label, String[] args)
  {
    if ((s instanceof Player))
    {
      Player p = (Player)s;
      if (args.length == 0)
      {
        if (MySQL.playerexists(p.getUniqueId()))
        {
          StatsManager stats = new StatsManager(p.getUniqueId());
          p.sendMessage("§7-- §eStats von §6" + p.getDisplayName()+" §7--");
          p.sendMessage("§7Kills§8: §e" + stats.getKills());
          p.sendMessage("§7Tode§8: §e" + stats.getTode());
          p.sendMessage("§7Punkte§8: §e" + stats.getPoints());
          double Kills = stats.getKills();
          double Tode = stats.getTode();
          
          double KD = Kills / Tode;
          KD *= 100.0D;
          KD = Math.round(KD);
          KD /= 100.0D;
          
          String kd = Double.valueOf(KD).toString();
          if (Tode == 0.0D) {
            p.sendMessage("§7K/D§8: §e" + Kills);
          } else {
            p.sendMessage("§7K/D§8: §e" + kd.replace("Infinity", "0").replace("NaN", "0"));
          }
          p.sendMessage("§7Gespielte Spiele§8: §e" + stats.getGespielt());
          p.sendMessage("§7Gewonnene Spiele§8: §e" + stats.getGewonnen());
        }
        else
        {
          p.sendMessage("§8» §cDer Spieler war noch nie Online!");
        }
      }
      else if (args.length == 1)
      {
        UUID uuid = UUIDFetcher.getUUID(args[0]);
        if (uuid != null)
        {
          if (MySQL.playerexists(uuid))
          {
            StatsManager stats = new StatsManager(uuid);
            p.sendMessage("§7-- §eStats von §6" + args[0] +" §7--");
            p.sendMessage("§7Kills§8: §e" + stats.getKills());
            p.sendMessage("§7Tode§8: §e" + stats.getTode());
            p.sendMessage("§7Punkte§8: §e" + stats.getPoints());
            double Kills = stats.getKills();
            double Tode = stats.getTode();
            
            double KD = Kills / Tode;
            KD *= 100.0D;
            KD = Math.round(KD);
            KD /= 100.0D;
            
            String kd = Double.valueOf(KD).toString();
            if (Tode == 0.0D) {
              p.sendMessage("§7K/D§8: §e" + Kills);
            } else {
              p.sendMessage("§7K/D§8: §e" + kd.replace("Infinity", "0").replace("NaN", "0"));
            }
            p.sendMessage("§7Gespielte Spiele§8: §e" + stats.getGespielt());
            p.sendMessage("§7Gewonnene Spiele§8: §e" + stats.getGewonnen());
          }
          else
          {
            p.sendMessage("§8» §cDer Spieler war noch nie online!");
          }
        }
        else {
          p.sendMessage("§8» §cDer Spieler war noch nie online!");
        }
      }
    }
    return false;
  }
}
