package de.CaptureTheWool.manager;

import de.CaptureTheWool.manager.StatsManager;

import de.CaptureTheWool.utils.MySQL;

import org.bukkit.entity.Player;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by Felix on 14.02.2017.
 */
public class AchievmentManager {

    Player p;

    public AchievmentManager(Player p) {
        this.p = p;
    }

    public boolean hasAchievment(Achievments achievments) {
        if(playerexists()) {
            try {
                ResultSet rs = MySQL.query("SELECT * FROM ach WHERE UUID='" + p.getUniqueId().toString() + "'");
                if (rs.next()) {
                    return Boolean.valueOf(rs.getString(achievments.toString()));
                }
                return true;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else{
            insert();
            hasAchievment(achievments);
        }
        return true;
    }
    public void setAchievment(Achievments achievment , boolean add) {
        if(playerexists()) {
            MySQL.update("UPDATE ach SET " + achievment.toString() + "='" + add + "' WHERE UUID='" + p.getUniqueId().toString() + "'");
            p.sendMessage("§6§k:fasdfasgdfA:FWAFsDF;ASGFAfa;ASDFSDF");
            p.sendMessage("§aDu hast das Achievment §e"+ achievment.getDisplayname()+" §aerhalten");
            p.sendMessage("§6§k:fasdfasgdfA:FWAFsDF;ASGFAfa;ASDFSDF");
            if(add == true) {
                StatsManager statsManager = new StatsManager(p.getUniqueId());
            }
        }else{
            insert();
            setAchievment(achievment, add);
        }
    }
    private boolean playerexists() {
        ResultSet rs = MySQL.query("SELECT * FROM ach WHERE UUID='" + p.getUniqueId().toString() + "'");
        try {
            if(rs.next()) {
                return (rs.getString("UUID") != null);
            }
            return false;
        }catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    private void insert() {
        MySQL.update("INSERT INTO ach (UUID, FIRSTPLAYED, FIRSTBLOOD, FIRSTWIN, FIRSTCRAFT, FIRSTDEATH, HUNDRET_KILLS) VALUES ('" + p.getUniqueId().toString() + "', 'false', 'false', 'false', 'false', 'false', 'false')");
    }
}