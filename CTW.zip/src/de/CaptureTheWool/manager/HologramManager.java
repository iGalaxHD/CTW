package de.CaptureTheWool.manager;

import java.io.PrintStream;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.UUID;
import de.CaptureTheWool.api.HologramAPI;
import de.CaptureTheWool.api.LocationAPI;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class HologramManager
  implements Listener
{
  public static HashMap<String, HologramAPI> holo = new HashMap();
  
  @EventHandler
  public void on(PlayerJoinEvent paramPlayerJoinEvent) throws SQLException
  {
    Player localPlayer = paramPlayerJoinEvent.getPlayer();
    if (holo.containsKey(localPlayer.getName()))
    {
      ((HologramAPI)holo.get(localPlayer.getName())).destory(localPlayer);
      holo.remove(localPlayer.getName());
    }
    if (!holo.containsKey(localPlayer.getName()))
    {StatsManager stats = new StatsManager(localPlayer.getUniqueId());
    
      Location localLocation = LocationAPI.getLocation("holo");
      
      String[] arrayOfString = { ("§3Name§8: §e")+localPlayer.getName(), 
        ("§3Kills§8: §e")+stats.getKills(), 
        ("§3Tode§8: §e")+stats.getTode(), 
        ("§3Points§8: §e")+stats.getPoints(), 
        ("§3Gespielte Spiele§8: §e")+stats.getGespielt(), 
        ("§3Gewonnene Spiele§8: §e")+stats.getGewonnen() };

      
      HologramAPI localHologram = new HologramAPI(localLocation, arrayOfString);
      localHologram.sendPlayer(localPlayer);
      holo.put(localPlayer.getName(), localHologram);
      System.out.println("Hologram gesetzt.");
    }
  }
}
