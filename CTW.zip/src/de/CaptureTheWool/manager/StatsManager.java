package de.CaptureTheWool.manager;


import de.CaptureTheWool.utils.MySQL;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

/**
 * Created by Felix on 25.01.2017.
 */
public class StatsManager {

    UUID UUID;

    public StatsManager(UUID playerUUID) {this.UUID = playerUUID;}

    /**
     * Kills: bekomme die Kill aus MySQL
     */

    public int getKills() {
        if(MySQL.playerexists(UUID)) {
            try {
                ResultSet rs = MySQL.query("SELECT * FROM stats WHERE UUID='" + UUID + "'");
                if (rs.next() && (Integer.valueOf(rs.getInt("KILLS")) != null)) {
                    return rs.getInt("KILLS");
                }
                return -1;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else{
            MySQL.createPlayer(UUID);
            getKills();
        }
        return -1;
    }
    public void setKills(int Kills) {
        if(MySQL.playerexists(UUID)) {
            MySQL.update("UPDATE stats SET KILLS='" + Kills + "' WHERE UUID='" + UUID + "'");
        }else{
            MySQL.createPlayer(UUID);
            setKills(Kills);
        }
    }
    public void addKills(int Kills) {
        if(MySQL.playerexists(UUID)) {
            Kills = Kills + getKills();
            setKills(Kills);
        }else{
            MySQL.createPlayer(UUID);
            addKills(Kills);
        }
    }
    public void removeKills(int Kills) {
        if(MySQL.playerexists(UUID)) {
            Kills = getKills() - Kills;
            setKills(Kills);
        }else{
            MySQL.createPlayer(UUID);
            removeKills(Kills);
        }
    }
    /**
     * Punkte: bekomme die Punkte aus MySQL
     */
    public int getPoints() {
        if(MySQL.playerexists(UUID)) {
            try {
                ResultSet rs = MySQL.query("SELECT * FROM stats WHERE UUID='" + UUID + "'");
                if (rs.next() && (Integer.valueOf(rs.getInt("POINTS")) != null)) {
                    return rs.getInt("POINTS");
                }
                return -1;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else{
            MySQL.createPlayer(UUID);
            getKills();
        }
        return -1;
    }
    public void setPoints(int Points) {
        if(MySQL.playerexists(UUID)) {
            MySQL.update("UPDATE stats SET Points='" + Points + "' WHERE UUID='" + UUID + "'");
        }else{
            MySQL.createPlayer(UUID);
            setPoints(Points);
        }
    }
    public void addPoints(int Points) {
        if(MySQL.playerexists(UUID)) {
        	Points = Points + getPoints();
            setPoints(Points);
        }else{
            MySQL.createPlayer(UUID);
            addPoints(Points);
        }
    }
    public void removePoints(int Points) {
        if(MySQL.playerexists(UUID)) {
        	Points = getPoints() - Points;
            setPoints(Points);
        }else{
            MySQL.createPlayer(UUID);
            removePoints(Points);
        }
    }
    /**
     * Tode: bekomme die Tode aus MySQL
     */
    public int getTode() {
        if(MySQL.playerexists(UUID)) {
            try {
                ResultSet rs = MySQL.query("SELECT * FROM stats WHERE UUID='" + UUID + "'");
                if (rs.next() && (Integer.valueOf(rs.getInt("TODE")) != null)) {
                    return rs.getInt("TODE");
                }
                return -1;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else{
            MySQL.createPlayer(UUID);
            getTode();
        }
        return -1;
    }
    public void setTode(int Tode) {
        if(MySQL.playerexists(UUID)) {
            MySQL.update("UPDATE stats SET TODE='" + Tode + "' WHERE UUID='" + UUID + "'");
        }else{
            MySQL.createPlayer(UUID);
            setTode(Tode);
        }
    }
    public void addTode(int Tode) {
        if(MySQL.playerexists(UUID)) {
            Tode = Tode + getTode();
            setKills(Tode);
        }else{
            MySQL.createPlayer(UUID);
            addTode(Tode);
        }
    }
    public void removeTode(int Tode) {
        if(MySQL.playerexists(UUID)) {
            Tode = getTode() - Tode;
            setKills(Tode);
        }else{
            MySQL.createPlayer(UUID);
            removeTode(Tode);
        }
    }
    /**
     * Gespielt: bekomme die Gespielt aus MySQL
     */

    public int getGespielt() {
        if(MySQL.playerexists(UUID)) {
            try {
                ResultSet rs = MySQL.query("SELECT * FROM stats WHERE UUID='" + UUID + "'");
                if (rs.next() && (Integer.valueOf(rs.getInt("GESPIELT")) != null)) {
                    return rs.getInt("GESPIELT");
                }
                return -1;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else{
            MySQL.createPlayer(UUID);
            getGespielt();
        }
        return -1;
    }
    public void setGespielt(int Gespielt) {
        if(MySQL.playerexists(UUID)) {
            MySQL.update("UPDATE stats SET GESPIELT='" + Gespielt + "' WHERE UUID='" + UUID + "'");
        }else{
            MySQL.createPlayer(UUID);
            setGespielt(Gespielt);
        }
    }
    public void addGespielt(int Gespielt) {
        if(MySQL.playerexists(UUID)) {
            Gespielt = Gespielt + getGespielt();
            setGespielt(Gespielt);
        }else{
            MySQL.createPlayer(UUID);
            addGespielt(Gespielt);
        }
    }
    public void removeGespielt(int Gespielt) {
        if(MySQL.playerexists(UUID)) {
            Gespielt = getGespielt() - Gespielt;
            setGespielt(Gespielt);
        }else{
            MySQL.createPlayer(UUID);
            removeGespielt(Gespielt);
        }
    }
    /**
     * Gewonnen: bekomme die Gewonnen aus MySQL
     */

    public int getGewonnen() {
        if(MySQL.playerexists(UUID)) {
            try {
                ResultSet rs = MySQL.query("SELECT * FROM stats WHERE UUID='" + UUID + "'");
                if (rs.next() && (Integer.valueOf(rs.getInt("GEWONNEN")) != null)) {
                    return rs.getInt("GEWONNEN");
                }
                return -1;
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else{
            MySQL.createPlayer(UUID);
            getGewonnen();
        }
        return -1;
    }
    public void setGewonnen(int Gewonnen) {
        if(MySQL.playerexists(UUID)) {
            MySQL.update("UPDATE stats SET GEWONNEN='" + Gewonnen + "' WHERE UUID='" + UUID + "'");
        }else{
            MySQL.createPlayer(UUID);
            setGewonnen(Gewonnen);
        }
    }
    public void addGewonnen(int Gewonnen) {
        if(MySQL.playerexists(UUID)) {
            Gewonnen = Gewonnen + getGewonnen();
            setGewonnen(Gewonnen);
        }else{
            MySQL.createPlayer(UUID);
            addGewonnen(Gewonnen);
        }
    }
    public void removeGewonnen(int Gewonnen) {
        if(MySQL.playerexists(UUID)) {
            Gewonnen = getGewonnen() - Gewonnen;
            setGewonnen(Gewonnen);
        }else{
            MySQL.createPlayer(UUID);
            removeGewonnen(Gewonnen);
        }
    }
    /**
     * Punkte: bekomme die Punkte aus MySQL
     */

    public void setName(String NAME) {
        if(MySQL.playerexists(UUID)) {
            MySQL.update("UPDATE stats SET NAME='" + NAME + "' WHERE UUID='" + UUID + "'");
        }else{
            MySQL.createPlayer(UUID);
            setName(NAME);
        }
    }
}