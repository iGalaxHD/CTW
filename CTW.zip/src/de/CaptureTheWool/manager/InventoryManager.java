package de.CaptureTheWool.manager;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

import de.CaptureTheWool.api.ItemCreator;

public class InventoryManager {
	
	public Inventory loadAchievments(Player p)
	  {
	    Inventory inv = Bukkit.createInventory(null, 27, "Achievments");
	    ItemCreator im = new ItemCreator();
	    AchievmentManager manager = new AchievmentManager(p);
	    
	    im.createItemwithLore2(Material.COAL, 1, 1, "§7???", "§8§m-----", "§7Noch nicht gefunden", inv, 10);
	    im.createItemwithLore2(Material.COAL, 1, 1, "§7???", "§8§m-----", "§7Noch nicht gefunden", inv, 11);
	    im.createItemwithLore2(Material.COAL, 1, 1, "§7???", "§8§m-----", "§7Noch nicht gefunden", inv, 12);
	    im.createItemwithLore2(Material.COAL, 1, 1, "§7???", "§8§m-----", "§7Noch nicht gefunden", inv, 14);
	    im.createItemwithLore2(Material.COAL, 1, 1, "§7???", "§8§m-----", "§7Noch nicht gefunden", inv, 15);
	    im.createItemwithLore2(Material.COAL, 1, 1, "§7???", "§8§m-----", "§7Noch nicht gefunden", inv, 16);
	    
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 0);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 1);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 2);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 3);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 4);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 5);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 6);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 7);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 8);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 9);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 13);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 17);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 18);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 19);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 20);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 21);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 22);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 23);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 24);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 25);
	    im.createItem(Material.STAINED_GLASS_PANE, 1, 7, " ", inv, 26);
	    if (manager.hasAchievment(Achievments.FIRSTPLAYED)) {
	      im.createItemwithLore2(Material.LEATHER_CHESTPLATE, 1, 0, "§7" + Achievments.FIRSTPLAYED.getDisplayname(), "§8§m-----", "§7Gefunden", inv, 10);
	    }
	    if (manager.hasAchievment(Achievments.FIRSTBLOOD)) {
	      im.createItemwithLore2(Material.INK_SACK, 1, 1, "§7" + Achievments.FIRSTBLOOD.getDisplayname(), "§8§m-----", "§7Gefunden", inv, 11);
	    }
	    if (manager.hasAchievment(Achievments.FIRSTCRAFT)) {
	      im.createItemwithLore2(Material.WORKBENCH, 1, 0, "§7" + Achievments.FIRSTCRAFT.getDisplayname(), "§8§m-----", "§7Gefunden", inv, 12);
	    }
	    if (manager.hasAchievment(Achievments.FIRSTDEATH)) {
	      im.createItemwithLore2(Material.IRON_SWORD, 1, 0, "§7" + Achievments.FIRSTDEATH.getDisplayname(), "§8§m-----", "§7Gefunden", inv, 14);
	    }
	    if (manager.hasAchievment(Achievments.FIRSTWIN)) {
	      im.createItemwithLore2(Material.DIRT, 1, 0, "§7" + Achievments.FIRSTWIN.getDisplayname(), "§8§m-----", "§7Gefunden", inv, 15);
	    }
	    if (manager.hasAchievment(Achievments.HUNDRET_KILLS)) {
	      im.createItemwithLore2(Material.DIAMOND_SWORD, 1, 0, "§7" + Achievments.HUNDRET_KILLS.getDisplayname(), "§8§m-----", "§7Gefunden", inv, 16);
	    }
	    return inv;
	  }
}
