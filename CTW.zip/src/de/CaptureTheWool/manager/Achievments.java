package de.CaptureTheWool.manager;

/**
 * Created by Felix on 04.02.2017.
 */
public enum Achievments {

    //the Achievements of the Game
    FIRSTPLAYED("Anfänger", 50),
    FIRSTBLOOD("Ab gehts", 200),
    FIRSTWIN("Weiter gehts", 300),
    FIRSTCRAFT("Crafter", 20),
    FIRSTDEATH("Erster Tod", 50),
    HUNDRET_KILLS("Killer", 1000);


    String displayname;
    int Coins;

    private Achievments(String displayname, int Coins) {
        this.displayname = displayname;
        this.Coins = Coins;
    }
    public String getDisplayname() {
        return displayname;
    }
    public int getCoins() {
        return Coins;
    }
}