package de.CaptureTheWool.listener;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

import de.CaptureTheWool.manager.InventoryManager;
import de.CaptureTheWool.utils.Data;
import de.CaptureTheWool.utils.GameState;

public class PlayerInteractListener implements Listener {

	@EventHandler
	public void onInteract(PlayerInteractEvent e) {
		Player p = e.getPlayer();
		try {
			if (!GameState.getState().equals(GameState.INGAME)) {
				e.setCancelled(true);
				if (e.getAction().equals(Action.RIGHT_CLICK_AIR) || e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
					if (e.getItem().getItemMeta().getDisplayName()
							.equalsIgnoreCase(Data.MSG.PREFIX+"§eTeam auswählen")) {
						Data.INVENTORY.openTeamSelector(p);
					} else if (e.getItem().getItemMeta().getDisplayName()
							.equalsIgnoreCase(Data.MSG.PREFIX+"§eSpiel bearbeiten")) {
						Data.INVENTORY.openEditItem(p);
					} else if (e.getItem().getItemMeta().getDisplayName()
							.equalsIgnoreCase(Data.MSG.PREFIX+"§eAchievments")) {
						e.getPlayer().openInventory(new InventoryManager().loadAchievments(e.getPlayer()));
					}else  if (e.getItem().getItemMeta().getDisplayName()
							.equalsIgnoreCase(Data.MSG.PREFIX + "§eZurück zur Lobby")) {
						p.sendMessage(Data.MSG.PREFIX + "§aVerbinde zur Lobby...");
						Data.sendToServer(p, "fallback");
					}
				}
			}
		} catch (Exception e2) {
		}
	}
}
