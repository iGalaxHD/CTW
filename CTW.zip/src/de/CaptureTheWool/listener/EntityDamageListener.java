package de.CaptureTheWool.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;

import de.CaptureTheWool.utils.GameState;

public class EntityDamageListener implements Listener{
	
	@EventHandler
	public void onFoodLevelCHange(EntityDamageEvent e){
		if(!GameState.getState().equals(GameState.INGAME)){
			e.setCancelled(true);
		}
	}
}
