package de.CaptureTheWool.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;

import de.CaptureTheWool.utils.GameState;

public class BlockBreakListener implements Listener{
	
	@EventHandler
	public void onBlockBreak(BlockBreakEvent e){
		if(!GameState.getState().equals(GameState.INGAME)){
			e.setCancelled(true);
		}else{
			e.setCancelled(false);
		}
	}
}
