package de.CaptureTheWool.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.FoodLevelChangeEvent;

import de.CaptureTheWool.utils.GameState;

public class FoodLevelChangeListener implements Listener{
	
	@EventHandler
	public void onFoodLevelCHange(FoodLevelChangeEvent e){
		if(!GameState.getState().equals(GameState.INGAME)){
			e.setCancelled(true);
		}
	}
}
