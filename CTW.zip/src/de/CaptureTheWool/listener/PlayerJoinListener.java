package de.CaptureTheWool.listener;

import de.CaptureTheWool.api.LocationAPI;
import de.CaptureTheWool.main.CaptureTheWool;
import de.CaptureTheWool.utils.Data;
import de.CaptureTheWool.utils.GameState;
import de.CaptureTheWool.utils.MySQL;
import de.CaptureTheWool.utils.Team;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;


public class PlayerJoinListener
		implements Listener {
	
	java.util.UUID UUID;
	
	@EventHandler
	public void onJoin(PlayerJoinEvent e) {
		final Player p = e.getPlayer();
		for (Player all : Bukkit.getOnlinePlayers()) {
			all.setScoreboard(Team.sb);
		}
		if(!MySQL.playerexists(p.getUniqueId()) ) {
			MySQL.createPlayer(p.getUniqueId());
		}
		
		p.setGameMode(GameMode.ADVENTURE);
		p.setHealth(20.0);
		p.setFoodLevel(20);
		if (GameState.getState().equals((Object)GameState.LOBBY) || GameState.getState().equals((Object)GameState.RESTART)) {
			e.setJoinMessage(Data.MSG.PREFIX + Data.LuckPermsHook.getPrefix(p) + p.getName() + " §ahat das Spiel betreten!");
			Data.ingameplayers.add(p);
			new Team.Manager(p).Select("NON");
			Team.setLobbySocreboard(p);		
			new BukkitRunnable(){

				public void run() {
					if (LocationAPI.existLocation("lobby")) {
						p.teleport(LocationAPI.getLocation("lobby"));
					}
				}
			}.runTaskLater((Plugin)Data.main, 5);
			Data.INVENTORY.clearInventory(p);
			Data.INVENTORY.giveLobbyItems(p);

		} else if (GameState.getState().equals((Object)GameState.INGAME)) {
			e.setJoinMessage("");
			p.setGameMode(GameMode.SPECTATOR);
			Data.Spec.add(p);
		}
	}

}