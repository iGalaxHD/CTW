package de.CaptureTheWool.listener;

import org.bukkit.event.Listener;

public class PlayerDeathListener implements Listener {

	//DeathListener
}
