package de.CaptureTheWool.listener;

import org.bukkit.event.Listener;

public class GameListener implements Listener {

  //Listener fürs Wolle Platzieren & prüfen ob die Position stimmt
 
}
