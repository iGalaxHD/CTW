package de.CaptureTheWool.listener;

import de.CaptureTheWool.utils.GameState;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerDropItemEvent;

/**
 * Created by TrainmasterHD on 25.02.2017.
 */

public class PlayerDropItemListener implements Listener {

    @EventHandler
    public void onDrop(PlayerDropItemEvent e){
        if(!GameState.getState().equals(GameState.INGAME)){
            e.setCancelled(true);
        }
    }
}
