package de.CaptureTheWool.listener;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import de.CaptureTheWool.utils.Data;
import de.CaptureTheWool.utils.GameState;

public class PlayerChatListener implements Listener {

	@EventHandler
	public void onPlayerChat(AsyncPlayerChatEvent e) {

		Player p = e.getPlayer();
		e.setCancelled(true);
		if (Data.ingameplayers.contains(p) && GameState.getState().equals(GameState.LOBBY)) {
			for (Player all : Bukkit.getOnlinePlayers()) {
				all.sendMessage("§7" + p.getName() + " §8» §f" + e.getMessage());
			}
		} 
		
		if (!e.getMessage().startsWith("@all") && Data.red.contains(p) && GameState.getState().equals(GameState.INGAME) || GameState.getState().equals(GameState.RESTART)) {
			for (Player all : Data.red) {
				all.sendMessage("§7[§6Team§7] §4" + p.getName() + " §8» §f" + e.getMessage());
			}
		}
		if (!e.getMessage().startsWith("@all") && Data.blue.contains(p) && GameState.getState().equals(GameState.INGAME) ||  GameState.getState().equals(GameState.RESTART) ) {
			for (Player all : Data.blue) {
				all.sendMessage("§7[§6Team§7] §9" + p.getName() + " §8» §f" + e.getMessage());
			}
		}
		if (!e.getMessage().startsWith("@all") && Data.Spec.contains(p) && GameState.getState().equals(GameState.INGAME) || GameState.getState().equals(GameState.RESTART)) {
			for (Player all : Data.Spec) {
				all.sendMessage("§7[§4✘§7] §7" + p.getName() + " §8» §f" + e.getMessage());
			}
		}
		if (e.getMessage().startsWith("@all") && Data.blue.contains(p)&& GameState.getState().equals(GameState.INGAME) || GameState.getState().equals(GameState.RESTART)) {
			for (Player all : Bukkit.getOnlinePlayers()) {
				all.sendMessage("§7[§6Global§7] §9" + p.getName() + " §8» §f" + e.getMessage().replace("@all", ""));
			}
		}
		if (e.getMessage().startsWith("@all") && Data.red.contains(p)&& GameState.getState().equals(GameState.INGAME) || GameState.getState().equals(GameState.RESTART)) {
			for (Player all : Bukkit.getOnlinePlayers()) {
				all.sendMessage("§7[§6Global§7] §4" + p.getName() + " §8» §f" + e.getMessage().replace("@all", ""));
			}
		}
	} 
	}