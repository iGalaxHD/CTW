package de.CaptureTheWool.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.server.ServerListPingEvent;

import de.CaptureTheWool.utils.GameState;

public class ServerListPingListener implements Listener{
	
	@EventHandler
	public void onServerPing(ServerListPingEvent e){
		if(GameState.getState().equals(GameState.LOBBY)){
			e.setMaxPlayers(18);
		}
	}
}
