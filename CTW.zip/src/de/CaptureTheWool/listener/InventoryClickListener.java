package de.CaptureTheWool.listener;

import de.CaptureTheWool.api.AnvilGUI;
import de.CaptureTheWool.api.ItemCreator;
import de.CaptureTheWool.api.LocationAPI;
import de.CaptureTheWool.utils.Countdown;
import de.CaptureTheWool.utils.Data;
import de.CaptureTheWool.utils.GameState;
import de.CaptureTheWool.utils.MapSystem;
import de.CaptureTheWool.utils.Team;
import java.util.ArrayList;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.util.BlockIterator;

public class InventoryClickListener
		implements Listener {
	@EventHandler
	public void onClick(InventoryClickEvent e) {
		final Player p = (Player)e.getWhoClicked();
		if (!GameState.getState().equals((Object)GameState.INGAME)) {
			e.setCancelled(true);
			if (e.getClickedInventory().getName() == "Achievments") {
		        e.setCancelled(true);
		      }
			if (e.getClickedInventory().getTitle().equalsIgnoreCase(Data.MSG.PREFIX + "§eTeam auswählen")) {
				if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Data.MSG.PREFIX + "§eTeam Blau")) {
					new Team.Manager(p).Select("Blue");
					ArrayList<String> teamselectorlore = new ArrayList<String>();
					teamselectorlore.add("");
					teamselectorlore.add(Data.MSG.PREFIX + "§7Rechsklick um ein");
					teamselectorlore.add(Data.MSG.PREFIX + "§7Team auszuw§hlen!");
					p.getInventory().setItem(0, ItemCreator.createItemwithMaterial(Material.WOOL, 11, 1, Data.MSG.PREFIX + "§eTeam auswählen", teamselectorlore));
				} else if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Data.MSG.PREFIX + "§eTeam Rot")) {
					new Team.Manager(p).Select("Red");
					ArrayList<String> teamselectorlore = new ArrayList<String>();
					teamselectorlore.add("");
					teamselectorlore.add(Data.MSG.PREFIX + "§7Rechsklick um ein");
					teamselectorlore.add(Data.MSG.PREFIX + "§7Team auszuwählen!");
					p.getInventory().setItem(0, ItemCreator.createItemwithMaterial(Material.WOOL, 14, 1, Data.MSG.PREFIX + "§eTeam auswählen", teamselectorlore));
				} else if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Data.MSG.PREFIX + "§eSchlie\u00dfen")) {
					p.closeInventory();
				}
			} else if (e.getClickedInventory().getTitle().equalsIgnoreCase(Data.MSG.PREFIX + "§cForceMap")) {
				if (e.getCurrentItem().getType() == Material.BARRIER) {
					p.closeInventory();
				} else if (e.getCurrentItem().getType() == Material.PAPER) {
					String mapname = e.getCurrentItem().getItemMeta().getDisplayName();
					if (mapname.equalsIgnoreCase(MapSystem.getSelectedMap())) {
						p.sendMessage(Data.MSG.PREFIX + "§cDie Map ist bereits ausgewählt!");
					} else {
						MapSystem.selectMap(mapname);
						Data.CLOUDSYSTEM.setState("Online");
						p.sendMessage(Data.MSG.PREFIX + "§aDie Map wurde zu §e" + mapname + " §ageforcemaped!");
						for (Player all : Bukkit.getOnlinePlayers()) {
							Team.setLobbySocreboard(all);
						}
					}
				}
			} else if (e.getClickedInventory().getTitle().equalsIgnoreCase(Data.MSG.PREFIX + "§eSpiel bearbeiten")) {
				if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Data.MSG.PREFIX + "§eSpiel starten")) {
					if (Bukkit.getOnlinePlayers().size() >= 2) {
						if (Countdown.lobbycount >= 10) {
							Countdown.lobbycount = 10;
							p.sendMessage(Data.MSG.PREFIX + "§aDer Countdown wurde auf §710 §aSekunden gesetzt!");
						} else {
							p.sendMessage(Data.MSG.PREFIX + "§cDer Countdown ist bereits unter 10 Sekunden!");
						}
					} else {
						p.sendMessage(Data.MSG.PREFIX + "§cEs sind nicht genug Spieler online, um das Spiel zu starten!");
					}
				} else if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Data.MSG.PREFIX + "§eSpiel setup")) {
					Data.INVENTORY.openSetup(p);
				} else if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Data.MSG.PREFIX + "§eKarte ändern")) {
					Data.INVENTORY.openForceMap(p);
				}
			} else if (e.getClickedInventory().getTitle().equalsIgnoreCase(Data.MSG.PREFIX + "§eSpiel setup")) {
				if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Data.MSG.PREFIX + "§eLocations")) {
					Data.INVENTORY.openLocationsSetup(p);
				}
				if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Data.MSG.PREFIX + "§eKarten")) {
					Data.INVENTORY.openMapSetup(p);
				}
			} else if (e.getClickedInventory().getTitle().equalsIgnoreCase(Data.MSG.PREFIX + "§eLocations Setup")) {
				if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Data.MSG.PREFIX + "§eLobby Location")) {
					if (e.getClick().isLeftClick()) {
						LocationAPI.setLocation("lobby", p);
						p.sendMessage(Data.MSG.PREFIX + "§aDu hast die Location §7Lobby §agesetzt!");
						Data.INVENTORY.openLocationsSetup(p);
					} else if (e.getClick().isRightClick()) {
						if (LocationAPI.existLocation("lobby")) {
							p.teleport(LocationAPI.getLocation("lobby"));
							p.sendMessage(Data.MSG.PREFIX + "§aDu hast dich zur Location §7Lobby §ateleportiert!");
							p.closeInventory();
						} else {
							p.sendMessage(Data.MSG.PREFIX + "§cDie Location existiert noch nicht!");
						}
					}
				}
				if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Data.MSG.PREFIX + "§eHolo Location")) {
					if (e.getClick().isLeftClick()) {
						LocationAPI.setLocation("holo", p);
						p.sendMessage(Data.MSG.PREFIX + "§aDu hast die Location §7Holo §agesetzt!");
						Data.INVENTORY.openLocationsSetup(p);
					} else if (e.getClick().isRightClick()) {
						if (LocationAPI.existLocation("holo")) {
							p.teleport(LocationAPI.getLocation("holo"));
							p.sendMessage(Data.MSG.PREFIX + "§aDu hast dich zur Location §7Holo §ateleportiert!");
							p.closeInventory();
						} else {
							p.sendMessage(Data.MSG.PREFIX + "§cDie Location existiert noch nicht!");
						}
					}
				}
			} else if (e.getClickedInventory().getTitle().equalsIgnoreCase(Data.MSG.PREFIX + "§aMap-Setup")) {
				if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase(Data.MSG.PREFIX + "§eMap erstellen.")) {
					AnvilGUI gui = new AnvilGUI(p, new AnvilGUI.AnvilClickEventHandler(){

						@Override
						public void onAnvilClick(AnvilGUI.AnvilClickEvent event) {
							if (event.getSlot() == AnvilGUI.AnvilSlot.OUTPUT) {
								if (!MapSystem.existMap(event.getName())) {
									MapSystem.createMap(event.getName());
									p.sendMessage(Data.MSG.PREFIX + "§aDu hast die Map §e" + event.getName() + " §aerstellt!");
								} else {
									p.sendMessage(Data.MSG.PREFIX + "§cDiese Map ist bereits erstellt worden!");
								}
								event.setWillDestroy(true);
								event.setWillClose(true);
							} else {
								event.setWillDestroy(false);
								event.setWillClose(false);
							}
						}
					});
					gui.setSlot(AnvilGUI.AnvilSlot.INPUT_LEFT, ItemCreator.createItemwithMaterial(Material.PAPER, 0, 1, "Map-Name...", null));
					gui.open();
				} else if (e.getCurrentItem().getType() == Material.PAPER) {
					Data.INVENTORY.openMapMainMenu(p, e.getCurrentItem().getItemMeta().getDisplayName());
				}
			} else if (e.getClickedInventory().getTitle().startsWith("§eSetup")) {
				if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§cMap Löschen")) {
					String[] as = e.getClickedInventory().getTitle().split(" ");
					String map = as.length == 3 ? as[1] + as[2] : as[1];
					if (MapSystem.existMap(map)) {
						MapSystem.removeMap(map);
						p.closeInventory();
						p.sendMessage(Data.MSG.PREFIX + "§aDie Map wurde erfolgreich gelöscht!");
					} else {
						p.closeInventory();
						p.sendMessage(Data.MSG.PREFIX + "§cDie Map existiert nicht!");
					}
				} else if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§aLocations")) {
					String[] as = e.getClickedInventory().getTitle().split(" ");
					String map = as.length == 3 ? as[1] + " " + as[2] : as[1];
					Data.INVENTORY.openMapLocationsSetup(p, map);
				}
			} else if (e.getClickedInventory().getTitle().startsWith("§aLocations")) {
				String[] ma = e.getClickedInventory().getTitle().split(" ");
				String mapname = ma.length == 3 ? ma[1] + " " + ma[2] : ma[1];
				if (e.getCurrentItem().getType() == Material.EYE_OF_ENDER) {
					if (e.getClick().isRightClick()) {
						if (MapSystem.existLocation(mapname, "spectator")) {
							Location loc = MapSystem.getLocation(mapname, "spectator");
							p.teleport(loc);
							p.sendMessage(Data.MSG.PREFIX + "§aDu hast dich zu der Location Teleportiert!");
							Data.INVENTORY.openMapLocationsSetup(p, mapname);
						} else {
							p.sendMessage(Data.MSG.PREFIX + "§cDiese Location wurde noch nicht gesetzt!");
						}
					} else if (e.getClick().isLeftClick()) {
						MapSystem.setLocation(mapname, "spectator", p.getLocation());
						p.sendMessage(Data.MSG.PREFIX + "§aDu hast die Location erfolgreich gesetzt!");
					}
				} else if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§9Blauer Spawn")) {
					if (e.getClick().isRightClick()) {
						if (MapSystem.existLocation(mapname, "spawnblue")) {
							Location loc = MapSystem.getLocation(mapname, "spawnblue");
							p.teleport(loc);
							p.sendMessage(Data.MSG.PREFIX + "§aDu hast dich zu der Location Teleportiert!");
							Data.INVENTORY.openMapLocationsSetup(p, mapname);
						} else {
							p.sendMessage(Data.MSG.PREFIX + "§cDiese Location wurde noch nicht gesetzt!");
						}
					} else if (e.getClick().isLeftClick()) {
						MapSystem.setLocation(mapname, "spawnblue", p.getLocation());
						p.sendMessage(Data.MSG.PREFIX + "§aDu hast die Location erfolgreich gesetzt!");
					}
				} else if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§4Roter Spawn")) {
					if (e.getClick().isRightClick()) {
						if (MapSystem.existLocation(mapname, "spawnred")) {
							Location loc = MapSystem.getLocation(mapname, "spawnred");
							p.teleport(loc);
							p.sendMessage(Data.MSG.PREFIX + "§aDu hast dich zu der Location Teleportiert!");
						} else {
							p.sendMessage(Data.MSG.PREFIX + "§cDiese Location wurde noch nicht gesetzt!");
						}
					} else if (e.getClick().isLeftClick()) {
						MapSystem.setLocation(mapname, "spawnred", p.getLocation());
						p.sendMessage(Data.MSG.PREFIX + "§aDu hast die Location erfolgreich gesetzt!");
						Data.INVENTORY.openMapLocationsSetup(p, mapname);
					}
				} else if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§9Blaue Wolle 1")) {
					if (e.getClick().isRightClick()) {
						if (MapSystem.existLocation(mapname, "woolblue1")) {
							Location loc = MapSystem.getLocation(mapname, "woolblue1");
							p.teleport(loc);
							p.sendMessage(Data.MSG.PREFIX + "§aDu hast dich zu der Location Teleportiert!");
						} else {
							p.sendMessage(Data.MSG.PREFIX + "§cDiese Location wurde noch nicht gesetzt!");
						}
					} else if (e.getClick().isLeftClick()) {
						BlockIterator iter = new BlockIterator((LivingEntity)p, 5);
						Block lastBlock = iter.next();
						while (iter.hasNext() && (lastBlock = iter.next()).getType() == Material.AIR) {
						}
						Location loc = lastBlock.getLocation();
						MapSystem.setLocation(mapname, "woolblue1", loc);
						loc.getBlock().setType(Material.AIR);
						p.sendMessage(Data.MSG.PREFIX + "§aDu hast die Location erfolgreich gesetzt!");
						Data.INVENTORY.openMapLocationsSetup(p, mapname);
					}
				} else if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§9Blaue Wolle 2")) {
					if (e.getClick().isRightClick()) {
						if (MapSystem.existLocation(mapname, "woolblue2")) {
							Location loc = MapSystem.getLocation(mapname, "woolblue2");
							p.teleport(loc);
							p.sendMessage(Data.MSG.PREFIX + "§aDu hast dich zu der Location Teleportiert!");
						} else {
							p.sendMessage(Data.MSG.PREFIX + "§cDiese Location wurde noch nicht gesetzt!");
						}
					} else if (e.getClick().isLeftClick()) {
						BlockIterator iter = new BlockIterator((LivingEntity)p, 5);
						Block lastBlock = iter.next();
						while (iter.hasNext() && (lastBlock = iter.next()).getType() == Material.AIR) {
						}
						Location loc = lastBlock.getLocation();
						MapSystem.setLocation(mapname, "woolblue2", loc);
						loc.getBlock().setType(Material.AIR);
						p.sendMessage(Data.MSG.PREFIX + "§aDu hast die Location erfolgreich gesetzt!");
						Data.INVENTORY.openMapLocationsSetup(p, mapname);
					}
				} else if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§4Rote Wolle 1")) {
					if (e.getClick().isRightClick()) {
						if (MapSystem.existLocation(mapname, "woolred1")) {
							Location loc = MapSystem.getLocation(mapname, "woolred1");
							p.teleport(loc);
							p.sendMessage(Data.MSG.PREFIX + "§aDu hast dich zu der Location Teleportiert!");
						} else {
							p.sendMessage(Data.MSG.PREFIX + "§cDiese Location wurde noch nicht gesetzt!");
						}
					} else if (e.getClick().isLeftClick()) {
						BlockIterator iter = new BlockIterator((LivingEntity)p, 5);
						Block lastBlock = iter.next();
						while (iter.hasNext() && (lastBlock = iter.next()).getType() == Material.AIR) {
						}
						Location loc = lastBlock.getLocation();
						MapSystem.setLocation(mapname, "woolred1", loc);
						loc.getBlock().setType(Material.AIR);
						p.sendMessage(Data.MSG.PREFIX + "§aDu hast die Location erfolgreich gesetzt!");
						Data.INVENTORY.openMapLocationsSetup(p, mapname);
					}
				} else if (e.getCurrentItem().getItemMeta().getDisplayName().equalsIgnoreCase("§4Rote Wolle 2")) {
					if (e.getClick().isRightClick()) {
						if (MapSystem.existLocation(mapname, "woolred2")) {
							Location loc = MapSystem.getLocation(mapname, "woolred2");
							p.teleport(loc);
							p.sendMessage(Data.MSG.PREFIX + "§aDu hast dich zu der Location Teleportiert!");
						} else {
							p.sendMessage(Data.MSG.PREFIX + "§cDiese Location wurde noch nicht gesetzt!");
						}
					} else if (e.getClick().isLeftClick()) {
						BlockIterator iter = new BlockIterator((LivingEntity)p, 5);
						Block lastBlock = iter.next();
						while (iter.hasNext() && (lastBlock = iter.next()).getType() == Material.AIR) {
						}
						Location loc = lastBlock.getLocation();
						MapSystem.setLocation(mapname, "woolred2", loc);
						loc.getBlock().setType(Material.AIR);
						p.sendMessage(Data.MSG.PREFIX + "§aDu hast die Location erfolgreich gesetzt!");
						Data.INVENTORY.openMapLocationsSetup(p, mapname);
					}
				}
			}
		}
	}

}