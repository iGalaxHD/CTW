package de.CaptureTheWool.listener;

import de.CaptureTheWool.utils.Data;
import de.CaptureTheWool.utils.GameState;
import de.CaptureTheWool.utils.Team;
import java.util.ArrayList;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerQuitListener
		implements Listener {
	@EventHandler
	public void onQuit(PlayerQuitEvent e) {
		Player p = e.getPlayer();
		if (GameState.getState().equals((Object)GameState.LOBBY) || GameState.getState().equals((Object)GameState.RESTART)) {
			e.setQuitMessage(Data.MSG.PREFIX + Data.LuckPermsHook.getPrefix(p) + p.getName() + " §ahat das Spiel verlassen!");
		} else if (GameState.getState().equals((Object)GameState.INGAME)) {
			if (Data.ingameplayers.contains((Object)p)) {
				Data.ingameplayers.remove((Object)p);
				e.setQuitMessage(Data.MSG.PREFIX + Data.LuckPermsHook.getPrefix(p) + p.getName() + " §ahat das Spiel verlassen!");
			} else {
				e.setQuitMessage("");
			}
			if (Data.red.contains((Object)p)) {
				Data.red.remove((Object)p);
				e.setQuitMessage(Data.MSG.PREFIX + Data.LuckPermsHook.getPrefix(p) + p.getName() + " §ahat das Spiel verlassen!");
			}
			if (Data.blue.contains((Object)p)) {
				Data.blue.remove((Object)p);
				e.setQuitMessage(Data.MSG.PREFIX + Data.LuckPermsHook.getPrefix(p) + p.getName() + " §ahat das Spiel verlassen!");
			}
		}
		Team.Manager manager = new Team.Manager(p);
		if (manager.getPlayer() != null) {
			manager.getPlayer().remove((Object)p);
		}
	}
}