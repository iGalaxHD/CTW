package de.CaptureTheWool.listener;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;


public class TeamListener implements Listener {
	// PvP in Teams ausmachen

	@EventHandler
	public void onFriendlyFire(EntityDamageByEntityEvent e) {
		
		
		
		
		

	}
}
