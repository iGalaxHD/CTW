package de.CaptureTheWool.listener;

import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;

import de.CaptureTheWool.utils.GameState;

public class BlockPlaceListener implements Listener{
	
	@EventHandler
	public void onBlockPlace(BlockPlaceEvent e){
		if(!GameState.getState().equals(GameState.INGAME)){
			e.setCancelled(true);
		}
	}

	
}
