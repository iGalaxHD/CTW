package de.CaptureTheWool.utils;

import de.CaptureTheWool.utils.Data;
import de.CaptureTheWool.utils.GameState;
import de.CaptureTheWool.utils.MapSystem;
import java.util.ArrayList;
import net.minecraft.server.v1_8_R3.EntityPlayer;
import net.minecraft.server.v1_8_R3.IScoreboardCriteria;
import net.minecraft.server.v1_8_R3.Packet;
import net.minecraft.server.v1_8_R3.PacketPlayOutScoreboardDisplayObjective;
import net.minecraft.server.v1_8_R3.PacketPlayOutScoreboardObjective;
import net.minecraft.server.v1_8_R3.PacketPlayOutScoreboardScore;
import net.minecraft.server.v1_8_R3.PlayerConnection;
import net.minecraft.server.v1_8_R3.ScoreboardObjective;
import net.minecraft.server.v1_8_R3.ScoreboardScore;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;

public class Team {
    public static org.bukkit.scoreboard.Scoreboard sb;

    public static void setLobbySocreboard(Player p) {
        net.minecraft.server.v1_8_R3.Scoreboard sb = new net.minecraft.server.v1_8_R3.Scoreboard();
        ScoreboardObjective obj = sb.registerObjective("  §6ZnapLax.de  ", IScoreboardCriteria.b);
        PacketPlayOutScoreboardObjective createPacket = new PacketPlayOutScoreboardObjective(obj, 0);
        PacketPlayOutScoreboardDisplayObjective display = new PacketPlayOutScoreboardDisplayObjective(1, obj);
        obj.setDisplayName("  §6ZnapLax.de  ");
        ScoreboardScore ss = new ScoreboardScore(sb, obj, " ");
        ss.setScore(6);
        ScoreboardScore ss2 = new ScoreboardScore(sb, obj, "  §eMap");
        ss2.setScore(5);
        ScoreboardScore ss3 = new ScoreboardScore(sb, obj, "   §8\u27a5§a" + MapSystem.getSelectedMap());
        ss3.setScore(4);
        ScoreboardScore ss4 = new ScoreboardScore(sb, obj, "  ");
        ss4.setScore(3);
        ScoreboardScore ss5 = new ScoreboardScore(sb, obj, "  §eServer");
        ss5.setScore(2);
        ScoreboardScore ss6 = new ScoreboardScore(sb, obj, "   §8\u27a5§c" + Data.CLOUDSYSTEM.getServer());
        ss6.setScore(1);
        ScoreboardScore ss7 = new ScoreboardScore(sb, obj, "   ");
        ss7.setScore(0);
        PacketPlayOutScoreboardObjective removePacket = new PacketPlayOutScoreboardObjective(obj, 1);
        PacketPlayOutScoreboardScore pa = new PacketPlayOutScoreboardScore(ss);
        PacketPlayOutScoreboardScore pa2 = new PacketPlayOutScoreboardScore(ss2);
        PacketPlayOutScoreboardScore pa3 = new PacketPlayOutScoreboardScore(ss3);
        PacketPlayOutScoreboardScore pa4 = new PacketPlayOutScoreboardScore(ss4);
        PacketPlayOutScoreboardScore pa5 = new PacketPlayOutScoreboardScore(ss5);
        PacketPlayOutScoreboardScore pa6 = new PacketPlayOutScoreboardScore(ss6);
        PacketPlayOutScoreboardScore pa7 = new PacketPlayOutScoreboardScore(ss7);
        Team.sendPacket(p, (Packet)removePacket);
        Team.sendPacket(p, (Packet)createPacket);
        Team.sendPacket(p, (Packet)display);
        Team.sendPacket(p, (Packet)pa);
        Team.sendPacket(p, (Packet)pa2);
        Team.sendPacket(p, (Packet)pa3);
        Team.sendPacket(p, (Packet)pa4);
        Team.sendPacket(p, (Packet)pa5);
        Team.sendPacket(p, (Packet)pa6);
        Team.sendPacket(p, (Packet)pa7);
    }

    public static void setGameScoreboard(Player p) {
        net.minecraft.server.v1_8_R3.Scoreboard sb = new net.minecraft.server.v1_8_R3.Scoreboard();
        ScoreboardObjective obj = sb.registerObjective("  §6ZnapLax.de  ", IScoreboardCriteria.b);
        PacketPlayOutScoreboardObjective createPacket = new PacketPlayOutScoreboardObjective(obj, 0);
        PacketPlayOutScoreboardDisplayObjective display = new PacketPlayOutScoreboardDisplayObjective(1, obj);
        obj.setDisplayName("  §6ZnapLax.de  ");
        ScoreboardScore ss = new ScoreboardScore(sb, obj, " §4");
        ss.setScore(8);
        ScoreboardScore ss1 = new ScoreboardScore(sb, obj, "  §9Blau");
        ss1.setScore(7);
        ScoreboardScore ss2 = new ScoreboardScore(sb, obj, "   §8\u27a5§4❒");
        ss2.setScore(6);
        ScoreboardScore ss3 = new ScoreboardScore(sb, obj, "   §8\u27a5§e❒");
        ss3.setScore(5);
        ScoreboardScore ss4 = new ScoreboardScore(sb, obj, "  §5");
        ss4.setScore(4);
        ScoreboardScore ss5 = new ScoreboardScore(sb, obj, "  §4Rot");
        ss5.setScore(3);
        ScoreboardScore ss6 = new ScoreboardScore(sb, obj, "   §8\u27a5§9❒");
        ss6.setScore(2);
        ScoreboardScore ss7 = new ScoreboardScore(sb, obj, "   §8\u27a5§b❒");
        ss7.setScore(1);
        ScoreboardScore ss8 = new ScoreboardScore(sb, obj, "   §7");
        ss8.setScore(0);
        PacketPlayOutScoreboardObjective removePacket = new PacketPlayOutScoreboardObjective(obj, 1);
        PacketPlayOutScoreboardScore pa = new PacketPlayOutScoreboardScore(ss);
        PacketPlayOutScoreboardScore pa1 = new PacketPlayOutScoreboardScore(ss1);
        PacketPlayOutScoreboardScore pa2 = new PacketPlayOutScoreboardScore(ss2);
        PacketPlayOutScoreboardScore pa3 = new PacketPlayOutScoreboardScore(ss3);
        PacketPlayOutScoreboardScore pa4 = new PacketPlayOutScoreboardScore(ss4);
        PacketPlayOutScoreboardScore pa5 = new PacketPlayOutScoreboardScore(ss5);
        PacketPlayOutScoreboardScore pa6 = new PacketPlayOutScoreboardScore(ss6);
        PacketPlayOutScoreboardScore pa7 = new PacketPlayOutScoreboardScore(ss7);
        PacketPlayOutScoreboardScore pa8 = new PacketPlayOutScoreboardScore(ss8);
        Team.sendPacket(p, (Packet)removePacket);
        Team.sendPacket(p, (Packet)createPacket);
        Team.sendPacket(p, (Packet)display);
        Team.sendPacket(p, (Packet)pa);
        Team.sendPacket(p, (Packet)pa1);
        Team.sendPacket(p, (Packet)pa2);
        Team.sendPacket(p, (Packet)pa3);
        Team.sendPacket(p, (Packet)pa4);
        Team.sendPacket(p, (Packet)pa5);
        Team.sendPacket(p, (Packet)pa6);
        Team.sendPacket(p, (Packet)pa7);
        Team.sendPacket(p, (Packet)pa8);
    }

    private static void sendPacket(Player p, Packet pa) {
        ((CraftPlayer)p).getHandle().playerConnection.sendPacket(pa);
    }

    public static class Scoreboard {
        public static void register() {
            Team.sb = Bukkit.getScoreboardManager().getNewScoreboard();
            Team.sb.registerNewTeam("Red");
            Team.sb.getTeam("Red").setPrefix("§4");
            Team.sb.registerNewTeam("Blue");
            Team.sb.getTeam("Blue").setPrefix("§9");
            Team.sb.registerNewTeam("Spec");
            Team.sb.registerNewTeam("NON");
            Team.sb.getTeam("NON").setPrefix("§7");
        }
    }

    public static class Manager {
        String pr = Data.MSG.PREFIX;
        Player p;

        public Manager(Player p) {
            this.p = p;
        }

        public void Select(String team) {
            if (team == "Red") {
                if (!Data.red.contains((Object)this.p)) {
                    if (Data.red.size() <= 8) {
                        if (Data.blue.contains((Object)this.p)) {
                            Data.blue.remove((Object)this.p);
                        }
                        this.p.sendMessage(this.pr + "§aDu bist Team §4Rot §abeigetreten.");
                        Team.sb.getTeam("Red").addPlayer((OfflinePlayer)this.p);
                        Data.red.add(this.p);
                        this.p.closeInventory();
                        for (Player all : Bukkit.getOnlinePlayers()) {
                            all.setScoreboard(Team.sb);
                        }
                    } else {
                        this.p.sendMessage(Data.MSG.PREFIX + "§cDas Team ist bereits voll");
                        Team.sb.getTeam("Blau").addPlayer((OfflinePlayer)this.p);
                    }
                } else {
                    this.p.sendMessage(this.pr + "§cDu bist bereits in dem Team!");
                }
            } else if (team == "Blue") {
                if (!Data.blue.contains((Object)this.p)) {
                    if (Data.blue.size() <= 8) {
                        if (Data.red.contains((Object)this.p)) {
                            Data.red.remove((Object)this.p);
                        }
                        Data.blue.add(this.p);
                        this.p.sendMessage(this.pr + "§aDu bist Team §9Blau §abeigetreten.");
                        Team.sb.getTeam("Blue").addPlayer((OfflinePlayer)this.p);
                        this.p.closeInventory();
                        for (Player all : Bukkit.getOnlinePlayers()) {
                            all.setScoreboard(Team.sb);
                        }
                    } else {
                        this.p.sendMessage(Data.MSG.PREFIX + "§cDas Team ist bereits voll");
                    }
                } else {
                    this.p.sendMessage(this.pr + "§cDu bist bereits in dem Team!");
                }
            } else if (team == "Spec") {
                if (GameState.getState() == GameState.INGAME) {
                    Team.sb.getTeam("Spec").addPlayer((OfflinePlayer)this.p);
                    Data.Spec.add(this.p);
                    this.p.closeInventory();
                }
            } else if (team == "NON" && GameState.getState() == GameState.LOBBY) {
                Team.sb.getTeam("NON").addPlayer((OfflinePlayer)this.p);
                this.p.closeInventory();
                Data.NoN.add(this.p);
            }
        }

        public String getTeam() {
            if (Data.blue.contains((Object)this.p)) {
                return "Blue";
            }
            if (Data.red.contains((Object)this.p)) {
                return "Red";
            }
            if (Data.NoN.contains((Object)this.p)) {
                return "NoN";
            }
            if (Data.Spec.contains((Object)this.p)) {
                return "Spec";
            }
            return null;
        }

        public ArrayList<Player> getPlayer() {
            if (Data.blue.contains((Object)this.p)) {
                return Data.blue;
            }
            if (Data.red.contains((Object)this.p)) {
                return Data.red;
            }
            if (Data.NoN.contains((Object)this.p)) {
                return Data.NoN;
            }
            if (Data.Spec.contains((Object)this.p)) {
                return Data.Spec;
            }
            return null;
        }
    }

}