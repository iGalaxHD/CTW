package de.CaptureTheWool.utils;

import de.CaptureTheWool.utils.Data;
import de.CaptureTheWool.utils.MySQL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

public class MapSystem {
	private static MySQL mysql = Data.mysql;
	public static String selectedmap;

	public static void setup() {
		mysql.update("CREATE TABLE IF NOT EXISTS Maps(MapName VARCHAR(100))");
		mysql.update("CREATE TABLE IF NOT EXISTS MapLocations(MapName VARCHAR(100), LocationName VARCHAR(100), Location VARCHAR(100))");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX + "§aMapSystem Setup abgeschlossen!");
	}

	public static void createMap(String mapname) {
		if (!MapSystem.existMap(mapname)) {
			mysql.update("INSERT INTO Maps(MapName) VALUES ('" + mapname + "')");
		}
	}

	public static void removeMap(String mapname) {
		if (MapSystem.existMap(mapname)) {
			mysql.update("DELETE FROM Maps WHERE MapName = '" + mapname + "'");
		}
	}

	public static void selectMap(String mapname) {
		if (MapSystem.existMap(mapname)) {
			selectedmap = mapname;
		}
	}

	public static String getSelectedMap() {
		return selectedmap;
	}

	public static boolean existMap(String mapname) {
		try {
			ResultSet rs = mysql.getResult("SELECT * FROM Maps WHERE MapName = '" + mapname + "'");
			if (rs.next()) {
				if (rs.getString("MapName") != null) {
					return true;
				}
				return false;
			}
			return false;
		}
		catch (SQLException rs) {
			return false;
		}
	}

	public static List<String> getMapList() {
		ArrayList<String> maps = new ArrayList<String>();
		try {
			ResultSet rs = mysql.getResult("SELECT MapName FROM Maps");
			while (rs.next()) {
				maps.add(rs.getString("MapName"));
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		return maps;
	}

	public static void setLocation(String mapname, String locationname, Location p) {
		if (MapSystem.existMap(mapname)) {
			World world = p.getWorld();
			double x = p.getX();
			double y = p.getY();
			double z = p.getZ();
			float yaw = p.getYaw();
			float pitch = p.getPitch();
			String loc = world.getName() + ";" + x + ";" + y + ";" + z + ";" + yaw + ";" + pitch;
			if (!MapSystem.existLocation(mapname, locationname)) {
				mysql.update("INSERT INTO MapLocations(MapName, LocationName, Location) VALUES ('" + mapname + "', '" + locationname + "', '" + loc + "')");
			} else {
				mysql.update("UPDATE MapLocations SET Location = '" + loc + "' WHERE MapName = '" + mapname + "' AND LocationName = '" + locationname + "'");
			}
		}
	}

	public static Location getLocation(String mapname, String locationname) {
		Location loc = new Location(Bukkit.getWorld((String)"world"), 0.0, 0.0, 0.0);
		try {
			ResultSet rs;
			if (MapSystem.existMap(mapname) && MapSystem.existLocation(mapname, locationname) && (rs = mysql.getResult("SELECT * FROM MapLocations WHERE MapName = '" + mapname + "' AND LocationName = '" + locationname + "'")).next()) {
				String[] locraw = rs.getString("Location").split(";");
				World world = Bukkit.getWorld((String)locraw[0]);
				double x = Double.parseDouble(locraw[1]);
				double y = Double.parseDouble(locraw[2]);
				double z = Double.parseDouble(locraw[3]);
				float yaw = Float.parseFloat(locraw[4]);
				float pitch = Float.parseFloat(locraw[5]);
				loc = new Location(world, x, y, z, yaw, pitch);
				return loc;
			}
		}
		catch (SQLException rs) {
			// empty catch block
		}
		return loc;
	}

	public static boolean existLocation(String mapname, String locationname) {
		try {
			ResultSet rs = mysql.getResult("SELECT * FROM MapLocations WHERE MapName = '" + mapname + "' AND LocationName = '" + locationname + "'");
			if (rs.next()) {
				if (rs.getString("LocationName") != null) {
					return true;
				}
				return false;
			}
			return false;
		}
		catch (SQLException rs) {
			return false;
		}
	}
}