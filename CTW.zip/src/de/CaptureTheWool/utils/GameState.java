package de.CaptureTheWool.utils;

/**
 * Created by TrainmasterHD on 25.02.2017.
 */

public enum GameState {
    LOBBY(), INGAME(), RESTART();

    private static GameState state;

    public static void setState(GameState state){
        GameState.state = state;
    }

    public static GameState getState(){
        return state;
    }
}
