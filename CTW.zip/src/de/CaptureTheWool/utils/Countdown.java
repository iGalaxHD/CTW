package de.CaptureTheWool.utils;

import de.CaptureTheWool.api.ActionBar;
import de.CaptureTheWool.api.LocationAPI;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;


public class Countdown {
	public static int lobbycount = 60;
	public static int ingamecount = 1200;
	public static int restartcount = 20;
	private static int lobbysched;
	private static int ingamesched;
	private static int restartsched;

	public static void startLobbyCountDown() {
		lobbysched = Bukkit.getScheduler().scheduleSyncRepeatingTask(Data.main, new Runnable() {
			public void run() {
				if (GameState.getState().equals(GameState.LOBBY)) {
					if (Bukkit.getOnlinePlayers().size() >= 16) {
						Data.CLOUDSYSTEM.setState("Full");
					}
					if (Bukkit.getOnlinePlayers().size() >= 2) {
						if ((Countdown.lobbycount == 60) || (Countdown.lobbycount == 50) || (Countdown.lobbycount == 40)
								|| (Countdown.lobbycount == 30) || (Countdown.lobbycount == 20)
								|| (Countdown.lobbycount == 10) || (Countdown.lobbycount == 5)
								|| (Countdown.lobbycount == 4) || (Countdown.lobbycount == 3)
								|| (Countdown.lobbycount == 2)) {
							for (Player all : Bukkit.getOnlinePlayers()) {
								all.sendMessage(Data.MSG.PREFIX + "§aDas Spiel startet in §7" + Countdown.lobbycount
										+ " §aSekunden!");
								de.CaptureTheWool.api.Title.sendTitle(all, 10, 10, 10, "§6" + Countdown.lobbycount,
										"§aSekunden");

							}
						} else if (Countdown.lobbycount == 1) {
							for (Player all : Bukkit.getOnlinePlayers()) {
								all.sendMessage(Data.MSG.PREFIX + "§aDas Spiel startet in §7" + Countdown.lobbycount
										+ "ner §aSekunde!");
								de.CaptureTheWool.api.Title.sendTitle(all, 10, 10, 10, "§6" + Countdown.lobbycount,
										"§aSekunde");
							}
						} else if (Countdown.lobbycount == 0) {
							for (Player all : Bukkit.getOnlinePlayers()) {
								all.sendMessage(Data.MSG.PREFIX + "§aDas Spiel startet jetzt!");
								all.setGameMode(GameMode.SURVIVAL);
								Data.INVENTORY.clearInventory(all);
								Team.setGameScoreboard(all);
								de.CaptureTheWool.api.Title.sendTitle(all, 10, 10, 10, "§6Los geht´s", "§aViel Glück");
							}
							for (Player all : Bukkit.getOnlinePlayers()) {
								if (new Team.Manager(all).getTeam() == "NoN") {
									int bluesize = Data.blue.size();
									int redsize = Data.red.size();

									Team.Manager manager = new Team.Manager(all);
									if (bluesize == redsize) {
										manager.Select("Blue");
									} else if (bluesize >= redsize) {
										manager.Select("Red");
									} else if (bluesize <= redsize) {
										manager.Select("Blue");
									}
								}
							}
							Bukkit.getScheduler().cancelTask(Countdown.lobbysched);
							GameState.setState(GameState.INGAME);
							Data.CLOUDSYSTEM.setState("InGame");
							Countdown.startInGameCountDown();
							for (Player blue : Data.blue) {
								if (MapSystem.existLocation(MapSystem.getSelectedMap(), "spawnblue")) {
									blue.teleport(MapSystem.getLocation(MapSystem.getSelectedMap(), "spawnblue"));
								}
							}
							for (Player red : Data.red) {
								if (MapSystem.existLocation(MapSystem.getSelectedMap(), "spawnred")) {
									red.teleport(MapSystem.getLocation(MapSystem.getSelectedMap(), "spawnred"));
								}
							}
							for (Player all : Bukkit.getOnlinePlayers()) {
								Team.setGameScoreboard(all);
							}
							Countdown.startInGameCountDown();
						}
						for (Player all : Bukkit.getOnlinePlayers()) {
							Countdown.setExpLobby(all, Countdown.lobbycount);
						}
						Countdown.lobbycount -= 1;
					} else {
						for (Player all : Bukkit.getOnlinePlayers()) {
							ActionBar.sendActionBar(all, "§cWarte auf weitere Spieler!");
							all.setExp(0.0F);
							all.setLevel(0);
							Countdown.lobbycount = 60;
						}
					}
				} else {
					Bukkit.getScheduler().cancelTask(Countdown.lobbysched);
				}
			}
		}, 20L, 20L);
	}

	public static void startInGameCountDown() {
		ingamesched = Bukkit.getScheduler().scheduleSyncRepeatingTask(Data.main, new Runnable() {
			public void run() {
				if (GameState.getState().equals(GameState.INGAME)) {
					if ((Data.blue.size() >= 1) && (Data.red.size() >= 1)) {
						if ((Countdown.ingamecount == 900) || (Countdown.ingamecount == 600)
								|| (Countdown.ingamecount == 300) || (Countdown.ingamecount == 180)
								|| (Countdown.ingamecount == 120) || (Countdown.ingamecount == 60)) {
							for (Player all : Bukkit.getOnlinePlayers()) {
								all.sendMessage(Data.MSG.PREFIX + "§aDas Spiel endet in §7" + Countdown.ingamecount / 60
										+ " §aMinuten!");
							}
						} else if ((Countdown.ingamecount == 50) || (Countdown.ingamecount == 40)
								|| (Countdown.ingamecount == 30) || (Countdown.ingamecount == 20)
								|| (Countdown.ingamecount == 10) || (Countdown.ingamecount == 5)
								|| (Countdown.ingamecount == 3) || (Countdown.ingamecount == 2)) {
							for (Player all : Bukkit.getOnlinePlayers()) {
								all.sendMessage(Data.MSG.PREFIX + "§aDas Spiel endet in §7" + Countdown.ingamecount
										+ " §aSekunden!");
							}
						} else if (Countdown.ingamecount == 1) {
							for (Player all : Bukkit.getOnlinePlayers()) {
								all.sendMessage(Data.MSG.PREFIX + "§aDas Spiel endet in §7" + Countdown.ingamecount
										+ "ner §aSekunde!");
							}
						} else if (Countdown.ingamecount == 0) {
							for (Player all : Bukkit.getOnlinePlayers()) {
								all.sendMessage(Data.MSG.PREFIX + "§aDas Spiel endet jetzt!");
								all.setGameMode(GameMode.ADVENTURE);
								if (LocationAPI.existLocation("lobby")) {
									all.teleport(LocationAPI.getLocation("lobby"));
								}
							}
							Bukkit.getScheduler().cancelTask(Countdown.ingamesched);
							GameState.setState(GameState.RESTART);
							Countdown.startRestartCountDown();
							Data.CLOUDSYSTEM.setState("Restart");

						}
						Countdown.ingamecount -= 1;
					} else {
						for (Player all : Bukkit.getOnlinePlayers()) {
							all.setExp(0.0F);
							all.setLevel(0);
							all.getInventory().clear();
							Bukkit.getScheduler().cancelTask(Countdown.ingamesched);
							GameState.setState(GameState.RESTART);
							Data.CLOUDSYSTEM.setState("Restart");
							Countdown.startRestartCountDown();
							Data.INVENTORY.giveEndItems(all);
							all.setFoodLevel(20);
							all.setGameMode(GameMode.ADVENTURE);
							all.setHealth(20);
							

							if (LocationAPI.existLocation("lobby")) {
								all.teleport(LocationAPI.getLocation("lobby"));
							}
							all.sendMessage(Data.MSG.PREFIX
									+ "§aDas Spiel wurde vorzeitig beendet, da nur noch ein Team existiert!");
							if (Data.blue.size() == 0) {
								all.sendMessage(Data.MSG.PREFIX + "§aTeam §cRot §ahat das Spiel gewonnen!");
							} else if (Data.red.size() == 0) {
								all.sendMessage(Data.MSG.PREFIX + "§aTeam §9Blau §ahat das Spiel gewonnen!");
							}

						}
					}
				} else {
					Bukkit.getScheduler().cancelTask(Countdown.ingamesched);
				}
			}
		}, 20L, 20L);
	}

	public static void startRestartCountDown() {
		if (!GameState.getState().equals(GameState.RESTART)) {
			Data.CLOUDSYSTEM.setState("Restart");
		}
		restartsched = Bukkit.getScheduler().scheduleSyncRepeatingTask(Data.main, new Runnable() {
			public void run() {
				if (GameState.getState().equals(GameState.RESTART)) {
					Data.CLOUDSYSTEM.setState("Restart");
					if ((Countdown.restartcount == 20) || (Countdown.restartcount == 10)
							|| (Countdown.restartcount == 5) || (Countdown.restartcount == 3)
							|| (Countdown.restartcount == 2)) {
						for (Player all : Bukkit.getOnlinePlayers()) {
							all.sendMessage(Data.MSG.PREFIX + "§aDer Server stoppt in §7" + Countdown.restartcount
									+ " §aSekunden!");
						}
					} else if (Countdown.restartcount == 1) {
						for (Player all : Bukkit.getOnlinePlayers()) {
							all.sendMessage(Data.MSG.PREFIX + "§aDer Server stoppt in §7" + Countdown.restartcount
									+ "ner §aSekunde!");
						}
					} else if (Countdown.restartcount == 0) {
						for (Player all : Bukkit.getOnlinePlayers()) {
							all.sendMessage(Data.MSG.PREFIX + "§aDer Server stoppt jetzt!");
							Data.red.remove(all);
							Data.blue.remove(all);
							Data.Spec.remove(all);
							Data.ingameplayers.remove(all);
							Data.sendToServer(all, "fallback");
						}
						new BukkitRunnable() {
							public void run() {
								Bukkit.getServer().shutdown();
							}
						}

								.runTaskLater(Data.main, 10L);
						Bukkit.getScheduler().cancelTask(Countdown.ingamesched);
					}
					for (Player all : Bukkit.getOnlinePlayers()) {
						Countdown.setExpRestart(all, Countdown.restartcount);
					}
					Countdown.restartcount -= 1;
				} else {
					Bukkit.getScheduler().cancelTask(Countdown.restartsched);
				}
			}
		}, 20L, 20L);
	}

	public static void setExpLobby(Player player, int time) {
		player.setExp(time / 60.0F);
		player.setLevel(time);
	}

	public static void setExpRestart(Player player, int time) {
		player.setExp(time / 20.0F);
		player.setLevel(time);
	}
}
