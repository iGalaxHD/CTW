package de.CaptureTheWool.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.function.Consumer;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

import de.CaptureTheWool.manager.UUIDFetcher;

public class MySQL {

	private String HOST = "";
	private int PORT = 0;
	private String DATABASE = "";
	private String USER = "";
	private String PASSWORD = "";

	private static MySQL instance;
	private static Connection con;
	private static ExecutorService executor;
	private static Plugin plugin;
	
	private static boolean ic;

	public MySQL(String host, int port, String database, String user, String password) {
		this.HOST = host;
		this.PORT = port;
		this.DATABASE = database;
		this.USER = user;
		this.PASSWORD = password;
	}

	public static boolean isConnected() {
		return ic;
	}

	public void connect() {
		try {
			con = DriverManager.getConnection(
					"jdbc:mysql://" + HOST + ":" + PORT + "/" + DATABASE + "?autoReconnect=true", USER, PASSWORD);
			Bukkit.getConsoleSender()
					.sendMessage(Data.MSG.PREFIX + "§aDie MySQL Verbindung wurde erfolgreich aufgebaut!");
			ic = true;
		} catch (SQLException e) {
			Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX
					+ "§cEs ist ein Fehler beim verbinden zur MySQL Datenbank aufgetreten! Fehler: " + e.getMessage());
			ic = false;
		}
	}

	public void close() {
		try {
			if (con != null) {
				con.close();
				Bukkit.getConsoleSender()
						.sendMessage(Data.MSG.PREFIX + "§aDie MySQL Verbindung wurde erfolgreich geschlossen!");
				ic = false;
			} else {
				Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX
						+ "§cDie MySQL Verbindung konnte nicht geschlossen werden, da keine offene Verbindung existiert!");
			}
		} catch (SQLException e) {
			Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX
					+ "§cDie MySQL Verbindung konnte nicht geschlossen werden! Fehler: " + e.getMessage());
		}
	}
	public static void update(String qry) {
		try {
			Statement st = con.createStatement();
			st.executeUpdate(qry);
			st.close();
		} catch (SQLException e) {
			System.err.println(e);
		}
	}
	public void query(String statment,Consumer<ResultSet> consumer){
		if(this.isConnected()){
		this.executor.execute(()->{
			ResultSet rs = this.query(statment);
			Bukkit.getScheduler().runTask(this.plugin, () ->{
				consumer.accept(rs);
			});
		});
	}}
	public static ResultSet query(PreparedStatement stat){
		if(isConnected()){
			try {
				return stat.executeQuery();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
	public static ResultSet query(String query){
		if(isConnected()){
			try {
				return query(con.prepareStatement(query));
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	public ResultSet getResult(String qry) {
		ResultSet rs = null;

		try {
			Statement st = con.createStatement();
			rs = st.executeQuery(qry);
		} catch (SQLException e) {
			System.err.println(e);
		}
		return rs;
	}
	 public static boolean playerexists(UUID UUID)
	  {
	    ResultSet rs = query("SELECT * FROM stats WHERE UUID='" + UUID.toString() + "'");
	    try
	    {
	      if (rs.next()) {
	        return rs.getString("UUID") != null;
	      }
	      return false;
	    }
	    catch (SQLException e)
	    {
	      e.printStackTrace();
	    }
	    return false;
	  }
	public static void createPlayer(UUID UUID)
	  {
	    update("INSERT INTO stats (UUID, NAME, KILLS, TODE, GEWONNEN, GESPIELT, POINTS) VALUES ('" + UUID.toString() + "', '" + UUIDFetcher.getName(UUID) + "', '0', '0', '0', '0', '0')");
	  }
	public static MySQL getInstance() {
		return instance;
	}
}
