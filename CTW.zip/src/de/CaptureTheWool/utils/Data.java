package de.CaptureTheWool.utils;

import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import com.google.gson.JsonObject;
import de.CaptureTheWool.api.ItemCreator;
import de.CaptureTheWool.api.LocationAPI;
import de.CaptureTheWool.main.CaptureTheWool;
import de.CaptureTheWool.utils.MapSystem;
import de.CaptureTheWool.utils.MySQL;
import de.devcubehd.cloudsystem.CloudSystemCore;
import de.devcubehd.cloudsystem.net.NetManager;
import de.devcubehd.cloudsystem.net.Ping;
import java.util.ArrayList;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import me.lucko.luckperms.api.Contexts;
import me.lucko.luckperms.api.LuckPermsApi;
import me.lucko.luckperms.api.User;
import me.lucko.luckperms.api.UuidCache;
import me.lucko.luckperms.api.caching.MetaData;
import me.lucko.luckperms.api.caching.UserData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.plugin.Plugin;

public class Data {
	public static CaptureTheWool main;
	public static LuckPermsApi api;
	public static LuckPermsHook lph;
	public static MySQL mysql;
	public static ArrayList<Player> ingameplayers;
	public static ArrayList<Player> blue;
	public static ArrayList<Player> red;
	public static ArrayList<Player> Spec;
	public static ArrayList<Player> NoN;

	public static void sendToServer(Player p, String server) {
		ByteArrayDataOutput out = ByteStreams.newDataOutput();
		out.writeUTF("Connect");
		out.writeUTF(server);
		p.sendPluginMessage((Plugin)main, "BungeeCord", out.toByteArray());
	}

	static {
		ingameplayers = new ArrayList();
		blue = new ArrayList();
		red = new ArrayList();
		Spec = new ArrayList();
		NoN = new ArrayList();
	}

	public static class LuckPermsHook {
		private static Optional<MetaData> getPlayerData(Player player) {
			Optional user = Data.api.getUserSafe(Data.api.getUuidCache().getUUID(player.getUniqueId()));
			if (!user.isPresent()) {
				return Optional.empty();
			}
			Optional contexts = Data.api.getContextForUser((User)user.get());
			if (!contexts.isPresent()) {
				return Optional.empty();
			}
			Optional userData = ((User)user.get()).getUserDataCache();
			if (!userData.isPresent()) {
				return Optional.empty();
			}
			return Optional.ofNullable(((UserData)userData.get()).getMetaData((Contexts)contexts.get()));
		}

		public static Optional<String> getPlayerPrefix(Player player) {
			return LuckPermsHook.getPlayerData(player).map(m -> Optional.ofNullable(m.getPrefix())).orElse(Optional.empty());
		}

		public Optional<String> getPlayerSuffix(Player player) {
			return LuckPermsHook.getPlayerData(player).map(m -> Optional.ofNullable(m.getSuffix())).orElse(Optional.empty());
		}

		public static String getPrefix(Player p) {
			String raw = " ";
			if (!LuckPermsHook.getPlayerPrefix(p).get().isEmpty()) {
				raw = ChatColor.translateAlternateColorCodes((char)'&', (String)LuckPermsHook.getPlayerPrefix(p).get());
			}
			return raw;
		}

		public String getSuffix(Player p) {
			String raw = ChatColor.translateAlternateColorCodes((char)'&', (String)this.getPlayerSuffix(p).get());
			return raw;
		}
	}

	public static class INVENTORY {
		public static void clearInventory(Player p) {
			p.getInventory().setArmorContents(null);
			p.getInventory().clear();
		}

		public static void openForceMap(Player p) {
			int i;
			Inventory inv = Bukkit.createInventory((InventoryHolder)null, (int)36, (String)(MSG.PREFIX + "§cForceMap"));
			for (i = 0; i < 36; ++i) {
				inv.setItem(i, ItemCreator.createItemwithMaterial(Material.STAINED_GLASS_PANE, 7, 1, "...", null));
			}
			i = 0;
			for (String m : MapSystem.getMapList()) {
				inv.setItem(i, ItemCreator.createItemwithMaterial(Material.PAPER, 0, 1, m, null));
				++i;
			}
			inv.setItem(35, ItemCreator.createItemwithMaterial(Material.BARRIER, 0, 1, "§cSchließen", null));
			p.openInventory(inv);
		}

		public static void giveLobbyItems(Player p) {
			ArrayList<String> teamselectorlore = new ArrayList<String>();
			teamselectorlore.add("§8§m----------------------------");
			teamselectorlore.add(MSG.PREFIX + "§7Rechsklick um ein");
			teamselectorlore.add(MSG.PREFIX + "§7Team auszuw\u00e4hlen!");
			p.getInventory().setItem(0, ItemCreator.createItemwithMaterial(Material.WOOL, 0, 1, MSG.PREFIX + "§eTeam ausw\u00e4hlen", teamselectorlore));
			ArrayList<String> achievments = new ArrayList<String>();
			achievments.add("§8§m----------------------------");
			achievments.add(MSG.PREFIX + "§7Rechsklick um");
			achievments.add(MSG.PREFIX + "§7deine Achievments zusehen!");
			p.getInventory().setItem(1, ItemCreator.createItemwithMaterial(Material.CHEST, 0, 1, MSG.PREFIX + "§eAchievments", achievments));
			if (p.hasPermission("ctw.modify")) {
				ArrayList<String> modifylore = new ArrayList<String>();
				modifylore.add("§8§m----------------------------");
				modifylore.add(MSG.PREFIX + "§7Rechsklick um das");
				modifylore.add(MSG.PREFIX + "§7Spiel zu bearbeiten!");
				p.getInventory().setItem(4, ItemCreator.createItemwithMaterial(Material.PAPER, 0, 1, MSG.PREFIX + "§eSpiel bearbeiten", modifylore));
			}
			ArrayList<String> backtohublore = new ArrayList<String>();
			backtohublore.add("§8§m----------------------------");
			backtohublore.add(MSG.PREFIX + "§7Rechsklick um auf");
			backtohublore.add(MSG.PREFIX + "§7die Lobby zu kommen!");
			p.getInventory().setItem(8, ItemCreator.createSkullItem("MHF_ArrowRight", MSG.PREFIX + "§eZurück zur Lobby", 1, backtohublore));
		}
		public static void giveEndItems(Player p) {
	
			ArrayList<String> achievments = new ArrayList<String>();
			achievments.add("§8§m----------------------------");
			achievments.add(MSG.PREFIX + "§7Rechsklick um");
			achievments.add(MSG.PREFIX + "§7deine Achievments zusehen!");
			p.getInventory().setItem(0, ItemCreator.createItemwithMaterial(Material.CHEST, 0, 1, MSG.PREFIX + "§eAchievments", achievments));
			
			ArrayList<String> backtohublore = new ArrayList<String>();
			backtohublore.add("§8§m----------------------------");
			backtohublore.add(MSG.PREFIX + "§7Rechsklick um auf");
			backtohublore.add(MSG.PREFIX + "§7die Lobby zu kommen!");
			p.getInventory().setItem(8, ItemCreator.createSkullItem("MHF_ArrowRight", MSG.PREFIX + "§eZurück zur Lobby", 1, backtohublore));
		}

		public static void openMapMainMenu(Player p, String mapname) {
			if (MapSystem.existMap(mapname)) {
				Inventory inv = Bukkit.createInventory((InventoryHolder)null, (int)9, (String)("§eSetup " + mapname));
				for (int i = 0; i < 9; ++i) {
					inv.setItem(i, ItemCreator.createItemwithMaterial(Material.STAINED_GLASS_PANE, 7, 1, "...", null));
				}
				ArrayList<String> blore = new ArrayList<String>();
				blore.add(" ");
				blore.add(MSG.PREFIX + "§7L\u00f6scht die Map");
				blore.add(MSG.PREFIX + "§7Es gibt kein zurück!");
				inv.setItem(8, ItemCreator.createItemwithMaterial(Material.BARRIER, 0, 1, "§cMap L\u00f6schen", blore));
				ArrayList<String> lorelocations = new ArrayList<String>();
				lorelocations.add(" ");
				lorelocations.add(MSG.PREFIX + "§7öffnet das Locations");
				lorelocations.add(MSG.PREFIX + "§7Setup Menü!");
				inv.setItem(0, ItemCreator.createItemwithMaterial(Material.WOOL, 5, 1, "§aLocations", lorelocations));
				p.openInventory(inv);
			}
		}

		public static void openMapLocationsSetup(Player p, String mapname) {
			Inventory inv = Bukkit.createInventory((InventoryHolder)null, (int)9, (String)("§aLocations " + mapname));
			for (int i = 0; i < 9; ++i) {
				inv.setItem(i, ItemCreator.createItemwithMaterial(Material.STAINED_GLASS_PANE, 7, 1, "...", null));
			}
			ArrayList<String> lorespec = new ArrayList<String>();
			if (MapSystem.existLocation(mapname, "spectator")) {
				Location loc = MapSystem.getLocation(mapname, "spectator");
				lorespec = new ArrayList();
				lorespec.add(" ");
				lorespec.add(MSG.PREFIX + "§7Location§8:");
				lorespec.add(MSG.PREFIX + "§7 X§8: §a" + loc.getX());
				lorespec.add(MSG.PREFIX + "§7 Y§8: §a" + loc.getY());
				lorespec.add(MSG.PREFIX + "§7 Z§8: §a" + loc.getZ());
				lorespec.add(MSG.PREFIX + "§7 Welt§8: §a" + loc.getWorld().getName());
				lorespec.add(" ");
				lorespec.add(MSG.PREFIX + "§7Linksklick, um die");
				lorespec.add(MSG.PREFIX + "§7Location zu setzen!");
				lorespec.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				lorespec.add(MSG.PREFIX + "§7der Location zu teleportieren!");
			} else {
				lorespec = new ArrayList();
				lorespec.add(" ");
				lorespec.add(MSG.PREFIX + "§7Linksklick, um die");
				lorespec.add(MSG.PREFIX + "§7Location zu setzen!");
				lorespec.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				lorespec.add(MSG.PREFIX + "§7der Location zu teleportieren!");
			}
			inv.setItem(0, ItemCreator.createItemwithMaterial(Material.EYE_OF_ENDER, 0, 1, "§7Spectator Spawn", lorespec));
			ArrayList<String> loreblue = new ArrayList<String>();
			if (MapSystem.existLocation(mapname, "spawnblue")) {
				Location loc = MapSystem.getLocation(mapname, "spawnblue");
				loreblue = new ArrayList();
				loreblue.add(" ");
				loreblue.add(MSG.PREFIX + "§7Location§8:");
				loreblue.add(MSG.PREFIX + "§7 X§8: §a" + loc.getX());
				loreblue.add(MSG.PREFIX + "§7 Y§8: §a" + loc.getY());
				loreblue.add(MSG.PREFIX + "§7 Z§8: §a" + loc.getZ());
				loreblue.add(MSG.PREFIX + "§7 Welt§8: §a" + loc.getWorld().getName());
				loreblue.add(" ");
				loreblue.add(MSG.PREFIX + "§7Linksklick, um die");
				loreblue.add(MSG.PREFIX + "§7Location zu setzen!");
				loreblue.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				loreblue.add(MSG.PREFIX + "§7der Location zu teleportieren!");
			} else {
				loreblue = new ArrayList();
				loreblue.add(" ");
				loreblue.add(MSG.PREFIX + "§7Linksklick, um die");
				loreblue.add(MSG.PREFIX + "§7Location zu setzen!");
				loreblue.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				loreblue.add(MSG.PREFIX + "§7der Location zu teleportieren!");
			}
			inv.setItem(2, ItemCreator.createItemwithMaterial(Material.WOOL, 11, 1, "§9Blauer Spawn", loreblue));
			ArrayList<String> loreblue1 = new ArrayList<String>();
			if (MapSystem.existLocation(mapname, "woolblue1")) {
				Location loc = MapSystem.getLocation(mapname, "woolblue1");
				loreblue1 = new ArrayList();
				loreblue1.add(" ");
				loreblue1.add(MSG.PREFIX + "§7Location§8:");
				loreblue1.add(MSG.PREFIX + "§7 X§8: §a" + loc.getX());
				loreblue1.add(MSG.PREFIX + "§7 Y§8: §a" + loc.getY());
				loreblue1.add(MSG.PREFIX + "§7 Z§8: §a" + loc.getZ());
				loreblue1.add(MSG.PREFIX + "§7 Welt§8: §a" + loc.getWorld().getName());
				loreblue1.add(" ");
				loreblue1.add(MSG.PREFIX + "§7Linksklick, um die");
				loreblue1.add(MSG.PREFIX + "§7Location zu setzen!");
				loreblue1.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				loreblue1.add(MSG.PREFIX + "§7der Location zu teleportieren!");
			} else {
				loreblue1 = new ArrayList();
				loreblue1.add(" ");
				loreblue1.add(MSG.PREFIX + "§7Linksklick, um die");
				loreblue1.add(MSG.PREFIX + "§7Location zu setzen!");
				loreblue1.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				loreblue1.add(MSG.PREFIX + "§7der Location zu teleportieren!");
			}
			inv.setItem(3, ItemCreator.createItemwithMaterial(Material.STAINED_CLAY, 11, 1, "§9Blaue Wolle 1", loreblue1));
			ArrayList<String> loreblue2 = new ArrayList<String>();
			if (MapSystem.existLocation(mapname, "woolblue2")) {
				Location loc = MapSystem.getLocation(mapname, "woolblue2");
				loreblue2 = new ArrayList();
				loreblue2.add(" ");
				loreblue2.add(MSG.PREFIX + "§7Location§8:");
				loreblue2.add(MSG.PREFIX + "§7 X§8: §a" + loc.getX());
				loreblue2.add(MSG.PREFIX + "§7 Y§8: §a" + loc.getY());
				loreblue2.add(MSG.PREFIX + "§7 Z§8: §a" + loc.getZ());
				loreblue2.add(MSG.PREFIX + "§7 Welt§8: §a" + loc.getWorld().getName());
				loreblue2.add(" ");
				loreblue2.add(MSG.PREFIX + "§7Linksklick, um die");
				loreblue2.add(MSG.PREFIX + "§7Location zu setzen!");
				loreblue2.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				loreblue2.add(MSG.PREFIX + "§7der Location zu teleportieren!");
			} else {
				loreblue2 = new ArrayList();
				loreblue2.add(" ");
				loreblue2.add(MSG.PREFIX + "§7Linksklick, um die");
				loreblue2.add(MSG.PREFIX + "§7Location zu setzen!");
				loreblue2.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				loreblue2.add(MSG.PREFIX + "§7der Location zu teleportieren!");
			}
			inv.setItem(4, ItemCreator.createItemwithMaterial(Material.STAINED_CLAY, 11, 1, "§9Blaue Wolle 2", loreblue2));
			ArrayList<String> lorered = new ArrayList<String>();
			if (MapSystem.existLocation(mapname, "spawnred")) {
				Location loc = MapSystem.getLocation(mapname, "spawnred");
				lorered = new ArrayList();
				lorered.add(" ");
				lorered.add(MSG.PREFIX + "§7Location§8:");
				lorered.add(MSG.PREFIX + "§7 X§8: §a" + loc.getX());
				lorered.add(MSG.PREFIX + "§7 Y§8: §a" + loc.getY());
				lorered.add(MSG.PREFIX + "§7 Z§8: §a" + loc.getZ());
				lorered.add(MSG.PREFIX + "§7 Welt§8: §a" + loc.getWorld().getName());
				lorered.add(" ");
				lorered.add(MSG.PREFIX + "§7Linksklick, um die");
				lorered.add(MSG.PREFIX + "§7Location zu setzen!");
				lorered.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				lorered.add(MSG.PREFIX + "§7der Location zu teleportieren!");
			} else {
				lorered = new ArrayList();
				lorered.add(" ");
				lorered.add(MSG.PREFIX + "§7Linksklick, um die");
				lorered.add(MSG.PREFIX + "§7Location zu setzen!");
				lorered.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				lorered.add(MSG.PREFIX + "§7der Location zu teleportieren!");
			}
			inv.setItem(6, ItemCreator.createItemwithMaterial(Material.WOOL, 14, 1, "§4Roter Spawn", lorered));
			ArrayList<String> lorered1 = new ArrayList<String>();
			if (MapSystem.existLocation(mapname, "woolred1")) {
				Location loc = MapSystem.getLocation(mapname, "woolred1");
				lorered1 = new ArrayList();
				lorered1.add(" ");
				lorered1.add(MSG.PREFIX + "§7Location§8:");
				lorered1.add(MSG.PREFIX + "§7 X§8: §a" + loc.getX());
				lorered1.add(MSG.PREFIX + "§7 Y§8: §a" + loc.getY());
				lorered1.add(MSG.PREFIX + "§7 Z§8: §a" + loc.getZ());
				lorered1.add(MSG.PREFIX + "§7 Welt§8: §a" + loc.getWorld().getName());
				lorered1.add(" ");
				lorered1.add(MSG.PREFIX + "§7Linksklick, um die");
				lorered1.add(MSG.PREFIX + "§7Location zu setzen!");
				lorered1.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				lorered1.add(MSG.PREFIX + "§7der Location zu teleportieren!");
			} else {
				lorered1 = new ArrayList();
				lorered1.add(" ");
				lorered1.add(MSG.PREFIX + "§7Linksklick, um die");
				lorered1.add(MSG.PREFIX + "§7Location zu setzen!");
				lorered1.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				lorered1.add(MSG.PREFIX + "§7der Location zu teleportieren!");
			}
			inv.setItem(7, ItemCreator.createItemwithMaterial(Material.STAINED_CLAY, 14, 1, "§4Rote Wolle 1", lorered1));
			ArrayList<String> lorered2 = new ArrayList<String>();
			if (MapSystem.existLocation(mapname, "woolred2")) {
				Location loc = MapSystem.getLocation(mapname, "woolred2");
				lorered2 = new ArrayList();
				lorered2.add(" ");
				lorered2.add(MSG.PREFIX + "§7Location§8:");
				lorered2.add(MSG.PREFIX + "§7 X§8: §a" + loc.getX());
				lorered2.add(MSG.PREFIX + "§7 Y§8: §a" + loc.getY());
				lorered2.add(MSG.PREFIX + "§7 Z§8: §a" + loc.getZ());
				lorered2.add(MSG.PREFIX + "§7 Welt§8: §a" + loc.getWorld().getName());
				lorered2.add(" ");
				lorered2.add(MSG.PREFIX + "§7Linksklick, um die");
				lorered2.add(MSG.PREFIX + "§7Location zu setzen!");
				lorered2.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				lorered2.add(MSG.PREFIX + "§7der Location zu teleportieren!");
			} else {
				lorered2 = new ArrayList();
				lorered2.add(" ");
				lorered2.add(MSG.PREFIX + "§7Linksklick, um die");
				lorered2.add(MSG.PREFIX + "§7Location zu setzen!");
				lorered2.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				lorered2.add(MSG.PREFIX + "§7der Location zu teleportieren!");
			}
			inv.setItem(8, ItemCreator.createItemwithMaterial(Material.STAINED_CLAY, 14, 1, "§4Rote Wolle 2", lorered2));
			p.openInventory(inv);
		}

		public static void openMapSetup(Player p) {
			int i;
			Inventory inv = Bukkit.createInventory((InventoryHolder)null, (int)36, (String)(MSG.PREFIX + "§aMap-Setup"));
			for (i = 0; i < 36; ++i) {
				inv.setItem(i, ItemCreator.createItemwithMaterial(Material.STAINED_GLASS_PANE, 7, 1, "...", null));
			}
			inv.setItem(31, ItemCreator.createItemwithMaterial(Material.NAME_TAG, 0, 1, MSG.PREFIX + "§eMap erstellen.", null));
			i = 0;
			for (String m : MapSystem.getMapList()) {
				inv.setItem(i, ItemCreator.createItemwithMaterial(Material.PAPER, 0, 1, m, null));
				++i;
			}
			p.openInventory(inv);
		}

		public static void openTeamSelector(Player p) {
			Inventory inv = Bukkit.createInventory((InventoryHolder)null, (int)27, (String)(MSG.PREFIX + "§eTeam ausw\u00e4hlen"));
			for (int i = 0; i < 27; ++i) {
				inv.setItem(i, ItemCreator.createItemwithMaterial(Material.STAINED_GLASS_PANE, 7, 1, "...", null));
			}
			ArrayList<String> loreblue = new ArrayList<String>();
			loreblue.add(" ");
			for (Player blue : Data.blue) {
				String lorestring = MSG.PREFIX + "§9";
				lorestring = lorestring + blue.getName();
				loreblue.add(lorestring);
			}
			inv.setItem(12, ItemCreator.createItemwithMaterial(Material.WOOL, 11, 1, MSG.PREFIX + "§eTeam Blau", loreblue));
			ArrayList<String> lorered = new ArrayList<String>();
			lorered.add(" ");
			for (Player red : Data.red) {
				String lorestring = MSG.PREFIX + "§c";
				lorestring = lorestring + red.getName();
				lorered.add(lorestring);
			}
			inv.setItem(14, ItemCreator.createItemwithMaterial(Material.WOOL, 14, 1, MSG.PREFIX + "§eTeam Rot", lorered));
			ArrayList<String> loreclose = new ArrayList<String>();
			loreclose.add(" ");
			loreclose.add(MSG.PREFIX + "§7Schließt das Men§!");
			inv.setItem(26, ItemCreator.createItemwithMaterial(Material.BARRIER, 0, 1, MSG.PREFIX + "§eSchließen", loreclose));
			p.openInventory(inv);
		}

		public static void openEditItem(Player p) {
			Inventory inv = Bukkit.createInventory((InventoryHolder)null, (int)27, (String)(MSG.PREFIX + "§eSpiel bearbeiten"));
			for (int i = 0; i < 27; ++i) {
				inv.setItem(i, ItemCreator.createItemwithMaterial(Material.STAINED_GLASS_PANE, 7, 1, "...", null));
			}
			if (p.hasPermission("ctw.start")) {
				ArrayList<String> loreforcestart = new ArrayList<String>();
				loreforcestart.add(" ");
				loreforcestart.add(MSG.PREFIX + "§7Setz den Countdown");
				loreforcestart.add(MSG.PREFIX + "§7auf 10 Sekunden!");
				inv.setItem(11, ItemCreator.createItemwithMaterial(Material.WATCH, 0, 1, MSG.PREFIX + "§eSpiel starten", loreforcestart));
			}
			if (p.hasPermission("ctw.se/setup")) {
				ArrayList<String> loresetup = new ArrayList<String>();
				loresetup.add(" ");
				loresetup.add(MSG.PREFIX + "§7öffnet das Spiel");
				loresetup.add(MSG.PREFIX + "§7Setup Menü!");
				inv.setItem(13, ItemCreator.createItemwithMaterial(Material.REDSTONE_COMPARATOR, 0, 1, MSG.PREFIX + "§eSpiel setup", loresetup));
			}
			if (p.hasPermission("ctw.forcemap")) {
				ArrayList<String> loreforcemap = new ArrayList<String>();
				loreforcemap.add(" ");
				loreforcemap.add(MSG.PREFIX + "§7Andert die Karte");
				loreforcemap.add(MSG.PREFIX + "§7auf der gespielt wird!");
				inv.setItem(15, ItemCreator.createItemwithMaterial(Material.EMPTY_MAP, 0, 1, MSG.PREFIX + "§eKarte \u00e4ndern", loreforcemap));
			}
			p.openInventory(inv);
		}

		public static void openSetup(Player p) {
			Inventory inv = Bukkit.createInventory((InventoryHolder)null, (int)27, (String)(MSG.PREFIX + "§eSpiel setup"));
			for (int i = 0; i < 27; ++i) {
				inv.setItem(i, ItemCreator.createItemwithMaterial(Material.STAINED_GLASS_PANE, 7, 1, "...", null));
			}
			ArrayList<String> lorelocations = new ArrayList<String>();
			lorelocations.add(" ");
			lorelocations.add(MSG.PREFIX + "§7öffnet das Locations");
			lorelocations.add(MSG.PREFIX + "§7Setup Menü!");
			inv.setItem(12, ItemCreator.createItemwithMaterial(Material.COMPASS, 0, 1, MSG.PREFIX + "§eLocations", lorelocations));
			ArrayList<String> loremaps = new ArrayList<String>();
			loremaps.add(" ");
			loremaps.add(MSG.PREFIX + "§7öffnet das Map");
			loremaps.add(MSG.PREFIX + "§7Setup Menü!");
			inv.setItem(14, ItemCreator.createItemwithMaterial(Material.EMPTY_MAP, 0, 1, MSG.PREFIX + "§eKarten", loremaps));
			p.openInventory(inv);
		}

		public static void openLocationsSetup(Player p) {
			Inventory inv = Bukkit.createInventory((InventoryHolder)null, (int)27, (String)(MSG.PREFIX + "§eLocations Setup"));
			for (int i = 0; i < 27; ++i) {
				inv.setItem(i, ItemCreator.createItemwithMaterial(Material.STAINED_GLASS_PANE, 7, 1, "...", null));
			}
			if (LocationAPI.existLocation("lobby")) {
				Location loc = LocationAPI.getLocation("lobby");
				ArrayList<String> lorelobby = new ArrayList<String>();
				lorelobby.add(" ");
				lorelobby.add(MSG.PREFIX + "§7Location§8:");
				lorelobby.add(MSG.PREFIX + "§7 X§8: §a" + loc.getX());
				lorelobby.add(MSG.PREFIX + "§7 Y§8: §a" + loc.getY());
				lorelobby.add(MSG.PREFIX + "§7 Z§8: §a" + loc.getZ());
				lorelobby.add(MSG.PREFIX + "§7 Welt§8: §a" + loc.getWorld().getName());
				lorelobby.add(" ");
				lorelobby.add(MSG.PREFIX + "§7Linksklick, um die");
				lorelobby.add(MSG.PREFIX + "§7Location zu setzen!");
				lorelobby.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				lorelobby.add(MSG.PREFIX + "§7der Location zu teleportieren!");
				inv.setItem(12, ItemCreator.createItemwithMaterial(Material.WOOL, 5, 1, MSG.PREFIX + "§eLobby Location", lorelobby));
			} else {
				ArrayList<String> lorelobby = new ArrayList<String>();
				lorelobby.add(" ");
				lorelobby.add(MSG.PREFIX + "§7Linksklick, um die");
				lorelobby.add(MSG.PREFIX + "§7Location zu setzen!");
				lorelobby.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				lorelobby.add(MSG.PREFIX + "§7der Location zu teleportieren!");
				inv.setItem(12, ItemCreator.createItemwithMaterial(Material.WOOL, 14, 1, MSG.PREFIX + "§eLobby Location", lorelobby));
			}
			if (LocationAPI.existLocation("holo")) {
				Location loc = LocationAPI.getLocation("holo");
				ArrayList<String> loreholo = new ArrayList<String>();
				loreholo.add(" ");
				loreholo.add(MSG.PREFIX + "§7Location§8:");
				loreholo.add(MSG.PREFIX + "§7 X§8: §a" + loc.getX());
				loreholo.add(MSG.PREFIX + "§7 Y§8: §a" + loc.getY());
				loreholo.add(MSG.PREFIX + "§7 Z§8: §a" + loc.getZ());
				loreholo.add(MSG.PREFIX + "§7 Welt§8: §a" + loc.getWorld().getName());
				loreholo.add(" ");
				loreholo.add(MSG.PREFIX + "§7Linksklick, um die");
				loreholo.add(MSG.PREFIX + "§7Location zu setzen!");
				loreholo.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				loreholo.add(MSG.PREFIX + "§7der Location zu teleportieren!");
				inv.setItem(14, ItemCreator.createItemwithMaterial(Material.WOOL, 5, 1, MSG.PREFIX + "§eHolo Location", loreholo));
			} else {
				ArrayList<String> loreholo = new ArrayList<String>();
				loreholo.add(" ");
				loreholo.add(MSG.PREFIX + "§7Linksklick, um die");
				loreholo.add(MSG.PREFIX + "§7Location zu setzen!");
				loreholo.add(MSG.PREFIX + "§7Rechtsklick, um dich zu");
				loreholo.add(MSG.PREFIX + "§7der Location zu teleportieren!");
				inv.setItem(14, ItemCreator.createItemwithMaterial(Material.WOOL, 14, 1, MSG.PREFIX + "§eHolo Location", loreholo));
			}
			p.openInventory(inv);
		}
	}

	public static class CLOUDSYSTEM {
		public static String getServer() {
			return CloudSystemCore.getServerName();
		}

		public static void setState(final String state) {
			NetManager.setPing((Ping)new Ping(){

				public JsonObject ping() {
					JsonObject packet = new JsonObject();
					packet.addProperty("packet", "PING");
					packet.addProperty("server", CloudSystemCore.getServerName());
					packet.addProperty("players", (Number)Bukkit.getOnlinePlayers().size());
					packet.addProperty("maxplayers", (Number)Bukkit.getMaxPlayers());
					packet.addProperty("status", state);
					packet.addProperty("motd", CloudSystemCore.getMotD());
					if (state != "Restart") {
						packet.addProperty("map", MapSystem.selectedmap);
					}
					return packet;
				}
			});
			NetManager.send((JsonObject)NetManager.getPing().ping());
		}

	}

	public static class MSG {
		public static String PREFIX = "§8» §r";
	}

}