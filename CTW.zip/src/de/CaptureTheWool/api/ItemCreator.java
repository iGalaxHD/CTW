package de.CaptureTheWool.api;

import java.util.ArrayList;

import org.bukkit.Material;
import org.bukkit.SkullType;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

public class ItemCreator {
	
	public static ItemStack createItemwithMaterial(Material m,int subid,int amount , String DisplayName, ArrayList<String> lore){
		ItemStack is = new ItemStack(m,amount,(short)subid);
		ItemMeta im = is.getItemMeta();
		im.setDisplayName(DisplayName);
		im.setLore(lore);
		is.setItemMeta(im);
		return is;
	}
	  public void createItem(Material mat, int Amount, int Byte, String dname, Inventory inv, int Slot)
	  {
	    ItemStack i = new ItemStack(mat, Amount, (short)Byte);
	    ItemMeta meta = i.getItemMeta();
	    meta.setDisplayName(dname);
	    i.setItemMeta(meta);
	    inv.setItem(Slot, i);
	  }
	public static ItemStack createSkullItem(String owner, String displayname, int amount, ArrayList<String> lore){
		ItemStack is = new ItemStack(Material.SKULL_ITEM, amount, (short)SkullType.PLAYER.ordinal());
		SkullMeta ism = (SkullMeta) is.getItemMeta();
		ism.setDisplayName(displayname);
		ism.setOwner(owner);
		ism.setLore(lore);
		is.setItemMeta(ism);
		return is;
	}
	public void createItemwithLore2(Material mat, int Amount, int Byte, String dname, String lore1, String lore2, Inventory inv, int Slot)
	  {
	    ItemStack i = new ItemStack(mat, Amount, (short)Byte);
	    ItemMeta meta = i.getItemMeta();
	    meta.setDisplayName(dname);
	    ArrayList<String> lore = new ArrayList();
	    lore.add(lore1);
	    lore.add(lore2);
	    meta.setLore(lore);
	    i.setItemMeta(meta);
	    inv.setItem(Slot, i);
	  }
	public static ItemStack CreateItemwithGlow(Material m,int subid,int amount , String DisplayName, ArrayList<String> lore){
		ItemStack is = new ItemStack(m,amount,(short)subid);
		ItemMeta im = is.getItemMeta();
		im.addEnchant(Enchantment.DURABILITY, 0, true);
		im.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		im.addItemFlags(ItemFlag.HIDE_DESTROYS);
		im.addItemFlags(ItemFlag.HIDE_PLACED_ON);
		im.setDisplayName(DisplayName);
		im.setLore(lore);
		is.setItemMeta(im);
		return is;
	}
	
}
