package de.CaptureTheWool.api;

import java.util.HashMap;
import net.minecraft.server.v1_8_R3.EntityArmorStand;
import net.minecraft.server.v1_8_R3.PacketPlayOutEntityDestroy;
import net.minecraft.server.v1_8_R3.PacketPlayOutSpawnEntityLiving;
import net.minecraft.server.v1_8_R3.WorldServer;
import org.bukkit.Location;
import org.bukkit.craftbukkit.v1_8_R3.CraftWorld;
import org.bukkit.craftbukkit.v1_8_R3.entity.CraftPlayer;
import org.bukkit.entity.Player;

public class HologramAPI
{
  Location loc;
  HashMap<Integer, EntityArmorStand> a;
  
  public HologramAPI(Location paramLocation, String[] paramArrayOfString)
  {
    this.loc = paramLocation;
    this.a = new HashMap();
    double d = paramLocation.getY();
    String[] arrayOfString;
    int j = (arrayOfString = paramArrayOfString).length;
    for (int i = 0; i < j; i++)
    {
      String str = arrayOfString[i];
      setupArmorStands(str, d);
      d -= 0.3D;
    }
  }
  
  public void destory(Player paramPlayer)
  {
    for (EntityArmorStand localEntityArmorStand : this.a.values())
    {
      PacketPlayOutEntityDestroy localPacketPlayOutEntityDestroy = new PacketPlayOutEntityDestroy(new int[] { localEntityArmorStand.getId() });
      ((CraftPlayer)paramPlayer).getHandle().playerConnection.sendPacket(localPacketPlayOutEntityDestroy);
    }
  }
  
  public void sendPlayer(Player paramPlayer)
  {
    for (EntityArmorStand localEntityArmorStand : this.a.values())
    {
      PacketPlayOutSpawnEntityLiving localPacketPlayOutSpawnEntityLiving = new PacketPlayOutSpawnEntityLiving(localEntityArmorStand);
      ((CraftPlayer)paramPlayer).getHandle().playerConnection.sendPacket(localPacketPlayOutSpawnEntityLiving);
    }
  }
  
  public void setupArmorStands(String paramString, double paramDouble)
  {
    WorldServer localWorldServer = ((CraftWorld)this.loc.getWorld()).getHandle();
    EntityArmorStand localEntityArmorStand = null;
    if (localEntityArmorStand == null) {
      localEntityArmorStand = new EntityArmorStand(localWorldServer);
    }
    localEntityArmorStand.setLocation(this.loc.getX(), paramDouble, this.loc.getZ(), 0.0F, 0.0F);
    localEntityArmorStand.setCustomName(paramString);
    localEntityArmorStand.setGravity(true);
    localEntityArmorStand.setInvisible(true);
    localEntityArmorStand.setCustomNameVisible(true);
    localEntityArmorStand.setSmall(true);
    this.a.put(Integer.valueOf(localEntityArmorStand.getId()), localEntityArmorStand);
  }
}
