package de.CaptureTheWool.api;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

import de.CaptureTheWool.utils.Data;
import de.CaptureTheWool.utils.MySQL;

public class LocationAPI {

	private static MySQL mysql = Data.mysql;

	public static void setup() {
		mysql.update("CREATE TABLE IF NOT EXISTS Locations(LocationName VARCHAR(100), Location VARCHAR(100))");
		Bukkit.getConsoleSender().sendMessage(Data.MSG.PREFIX + "§aLocationAPI Setup abgeschlossen!");
	}

	public static void setLocation(String locationname, Player p) {
		World world = p.getLocation().getWorld();
		double x = p.getLocation().getX();
		double y = p.getLocation().getY();
		double z = p.getLocation().getZ();
		float yaw = p.getLocation().getYaw();
		float pitch = p.getLocation().getPitch();
		String loc = world.getName() + ";" + x + ";" + y + ";" + z + ";" + yaw + ";" + pitch;
		if (!existLocation(locationname)) {
			mysql.update(
					"INSERT INTO Locations(LocationName, Location) VALUES ('" + locationname + "', '" + loc + "')");
		} else {
			mysql.update("UPDATE Locations SET Location = '" + loc + "' WHERE LocationName = '" + locationname + "'");
		}
	}

	public static Location getLocation(String locationname) {
		Location loc = new Location(Bukkit.getWorld("world"), 0.0, 0.0, 0.0);
		try {
			if (existLocation(locationname)) {
				ResultSet rs = mysql.getResult("SELECT * FROM Locations WHERE LocationName = '" + locationname + "'");
				if (rs.next()) {
					String[] locraw = rs.getString("Location").split(";");
					World world = Bukkit.getWorld(locraw[0]);
					double x = Double.parseDouble(locraw[1]);
					double y = Double.parseDouble(locraw[2]);
					double z = Double.parseDouble(locraw[3]);
					float yaw = Float.parseFloat(locraw[4]);
					float pitch = Float.parseFloat(locraw[5]);
					loc = new Location(world, x, y, z, yaw, pitch);
					return loc;
				}
			}
		} catch (SQLException e) {
		}
		return loc;
	}

	public static boolean existLocation(String locationname) {
		try {
			ResultSet rs = mysql.getResult("SELECT * FROM Locations WHERE LocationName = '" + locationname + "'");
			if (rs.next()) {
				if (rs.getString("LocationName") != null) {
					return true;
				} else {
					return false;
				}
			}
			return false;
		} catch (SQLException e) {
		}
		return false;
	}
}
